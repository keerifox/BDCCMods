extends Module

var target = load("res://Player/Player3D/Parts/Part3D.gd")

func _init():
	id = "ClippingBarrier"
	author = "bringulbangul"
	scenes = []
	events = []
	gameExtenders = []
	bodyparts = [
		
	]
	stageScenes = [
		"res://Modules/ClippingBarrier/StageScenes/ButtStackSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/Choking.tscn",
		"res://Modules/ClippingBarrier/StageScenes/HangingSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/HK_ArmsRaisedSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/PuppySexAllFours.tscn",
		"res://Modules/ClippingBarrier/StageScenes/PuppySexCowgirl.tscn",
		"res://Modules/ClippingBarrier/StageScenes/RopesSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexAgainstWall.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexAllFours.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexBehind.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexCowgirl.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexCowgirlAlt.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexCowgirlAmazon.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexCowgirlChoke.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexDoubleDown.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexDP.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexFreeStanding.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexFullNelson.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexGangbang.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexLotus.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexLowDoggy.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexMatingPress.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexMissionary.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexOverTable.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexPawLick.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexPinnedBehind.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexReverseCowgirl.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexSpitroast.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexStanding.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexStandRide.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexStealth.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexTrain.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SexVent.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SlutwallRide.tscn",
		"res://Modules/ClippingBarrier/StageScenes/SlutwallSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/StocksSex.tscn",
		"res://Modules/ClippingBarrier/StageScenes/StocksSpitroast.tscn",
		"res://Modules/ClippingBarrier/StageScenes/UrinalSex.tscn",
		
	]
	

func preInit(): # Called before anything gets registered
	pass

var hook = "\tif(String(self.get_path()).ends_with(\"Body\")):\n\t\tvar _mask = bodymask.instance()\n\t\tself.get_node(\".\").add_child(_mask)\n\t\t_mask.software_skinning_transform_normals = false\n\t\t_mask.skeleton = _mask.get_path_to(dollSkeleton.getSkeleton())\n"

var t0 = "#\t\t\tchild.skeleton = child.get_path_to(dollSkeleton.getSkeleton())\n"

#func postInit(): # Called after everything is registered
#	var target = load("res://Player/Player3D/Parts/Part3D.gd")
#	var original = target.source_code
#	var modified = original.replace(t0, t0+hook)
#	modified = modified.replace("var meshesThatUpdateMaterial = []\n", "var meshesThatUpdateMaterial = []\nvar bodymask = preload(\"res://Modules/ClippingBarrier/bodymask.tscn\")")
#	target.source_code = modified
#	target.reload()
#	print(modified)


#	if(String(self.get_path()).ends_with("Body")):
#		var _mask = load("res://Modules/LustierCombat/bodymask.tscn").instance()
#		_mask.name = "mask"
#		self.add_child(_mask)
#		_mask.software_skinning_transform_normals = false
#		_mask.skeleton = _mask.get_path_to(dollSkeleton.getSkeleton())
#		_mask.transform = Transform(Vector3(0.979,0,0),Vector3(0,0.7,0),Vector3(0,0,1), Vector3(0.031,1.496,0.1))
