shader_type spatial;
render_mode unshaded;

void fragment() {
	ALBEDO = textureLod(SCREEN_TEXTURE, SCREEN_UV, 1.0).rgb;
}