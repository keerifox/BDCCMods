extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var animationTree3 = $AnimationTree3
onready var doll = $Doll3D
onready var doll2 = $Doll3D2
onready var doll3 = $Doll3D3

func _init():
	id = StageScene.SexDP

func _ready():
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer2())
	animationTree.active = true
	animationTree2.anim_player = animationTree2.get_path_to(doll2.getAnimPlayer2())
	animationTree2.active = true
	animationTree3.anim_player = animationTree3.get_path_to(doll3.getAnimPlayer2())
	animationTree3.active = true
	
func updateSubAnims():
	if(true):
		return
	if(doll.getArmsCuffed()):
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
	
	if(doll2.getArmsCuffed()):
		animationTree2["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree2["parameters/CuffsBlend/blend_amount"] = 0.0

	if(doll3.getArmsCuffed()):
		animationTree3["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree3["parameters/CuffsBlend/blend_amount"] = 0.0

# StageScene.Duo, "kneel", {npc="nova", pc="pc"}
func playAnimation(animID, _args = {}):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	doll2.prepareCharacter(secondDoll)
	var thirdDoll = "pc"
	if(_args.has("npc2")):
		thirdDoll = _args["npc2"]
	doll3.prepareCharacter(thirdDoll)
	
	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	if(_args.has("npcBodyState")):
		doll2.applyBodyState(_args["npcBodyState"])
	else:
		doll2.applyBodyState({})
	
	if(_args.has("npc2BodyState")):
		doll3.applyBodyState(_args["npc2BodyState"])
	else:
		doll3.applyBodyState({})
	
	updateSubAnims()
	
	var state_machine = animationTree["parameters/StateMachine/playback"]
	var state_machine2 = animationTree2["parameters/StateMachine/playback"]
	var state_machine3 = animationTree3["parameters/StateMachine/playback"]

	if(_args.has("npcCum") && _args["npcCum"] && !(animID in ["tease"])):
		startCumInsideSolo(doll, getCumIntensity(doll2) + getCumIntensity(doll3))
		#startCumInside(doll, doll2)
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
		
	var thePart2 # meshinstance -> mesh -> material -> texture
	var thePart3
	if(doll2.parts.has(BodypartSlot.Penis)): # doll2 and doll3 is the dom for this scene
		thePart2 = doll2.parts[BodypartSlot.Penis]
	if(doll3.parts.has(BodypartSlot.Penis)): # doll2 and doll3 is the dom for this scene
		thePart3 = doll3.parts[BodypartSlot.Penis]
		
	doll.parts[BodypartSlot.Body].get_children()[-1].visible = true

	if(animID == "tease"):
		state_machine.travel("SexDPTease_1-loop")
		state_machine2.travel("SexDPTease_2-loop")
		state_machine3.travel("SexDPTease_3-loop")
		doll.parts[BodypartSlot.Body].get_children()[-1].visible = false
		for idx in [0,1]: # get the mesh, there's 4 meshes for usual penis
			var themesh = thePart2.meshesThatUpdateMaterial[idx] #mesh 1 is the penis, 2 is the condom sprite. 3 and 4 are for non-erect and caged versions, so we skip
			var mat = themesh.get_active_material(0) # need to modify the material, assume first material because nothing in the game uses more than 1
			mat.render_priority = 0 # the masking layer is rendered at -1, by rendering at 0 it's in front of the mask and is visible
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = 0
	if(animID == "inside"):
		state_machine.travel("SexDPInside_1-loop")
		state_machine2.travel("SexDPInside_2-loop")
		state_machine3.travel("SexDPInside_3-loop")
		for idx in [0,1]: 
			var themesh = thePart2.meshesThatUpdateMaterial[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2
	if(animID == "sex"):
		state_machine.travel("SexDP_1-loop")
		state_machine2.travel("SexDP_2-loop")
		state_machine3.travel("SexDP_3-loop")
		for idx in [0,1]: 
			var themesh = thePart2.meshesThatUpdateMaterial[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2
	if(animID == "fast"):
		state_machine.travel("SexDPFast_1-loop")
		state_machine2.travel("SexDPFast_2-loop")
		state_machine3.travel("SexDPFast_3-loop")
		for idx in [0,1]: 
			var themesh = thePart2.meshesThatUpdateMaterial[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2



func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	var thirdDoll = "pc"
	if(_args.has("npc2")):
		thirdDoll = _args["npc2"]
		
	if(doll.getCharacterID() != firstDoll || doll2.getCharacterID() != secondDoll || doll3.getCharacterID() != thirdDoll):
		return false
	return true

func getSupportedStates():
	return ["tease", "inside", "sex", "fast"]

func getVarNpcs():
	return ["pc", "npc", "npc2"]
