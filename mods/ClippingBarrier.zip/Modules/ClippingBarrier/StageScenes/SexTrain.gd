extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var animationTree3 = $AnimationTree3
onready var doll = $Doll3D
onready var doll2 = $Doll3D2
onready var doll3 = $Doll3D3

func _init():
	id = StageScene.SexTrain

func _ready():
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer2())
	animationTree.active = true
	animationTree2.anim_player = animationTree2.get_path_to(doll2.getAnimPlayer2())
	animationTree2.active = true
	animationTree3.anim_player = animationTree3.get_path_to(doll3.getAnimPlayer2())
	animationTree3.active = true
	
func updateSubAnims():
	if(true):
		return
	if(doll.getArmsCuffed()):
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
	
	if(doll2.getArmsCuffed()):
		animationTree2["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree2["parameters/CuffsBlend/blend_amount"] = 0.0

	if(doll3.getArmsCuffed()):
		animationTree3["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree3["parameters/CuffsBlend/blend_amount"] = 0.0

# StageScene.Duo, "kneel", {npc="nova", pc="pc"}
func playAnimation(animID, _args = {}):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	doll2.prepareCharacter(secondDoll)
	var thirdDoll = "pc"
	if(_args.has("npc2")):
		thirdDoll = _args["npc2"]
	doll3.prepareCharacter(thirdDoll)
	
	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	if(_args.has("npcBodyState")):
		doll2.applyBodyState(_args["npcBodyState"])
	else:
		doll2.applyBodyState({})
	
	if(_args.has("npc2BodyState")):
		doll3.applyBodyState(_args["npc2BodyState"])
	else:
		doll3.applyBodyState({})
	
	if(_args.has("pcCum") && _args["pcCum"]):
		#startCumInsideSolo(doll, getCumIntensity(doll2) + getCumIntensity(doll3))
		if(!(animID in ["tease"])):
			startCumInside(doll2, doll)
		else:
			startCumPenis(doll)
	if(_args.has("npcCum") && _args["npcCum"]):
		#startCumInsideSolo(doll, getCumIntensity(doll2) + getCumIntensity(doll3))
		if(!(animID in ["tease"])):
			startCumInside(doll, doll3)
		else:
			startCumPenis(doll3)
	if(_args.has("npc2Cum") && _args["npc2Cum"]):
		startCumPenis(doll2)
	
	updateSubAnims()
	
	var state_machine = animationTree["parameters/StateMachine/playback"]
	var state_machine2 = animationTree2["parameters/StateMachine/playback"]
	var state_machine3 = animationTree3["parameters/StateMachine/playback"]
	
	var theParts # meshinstance -> mesh -> material -> texture
	var thePart3
	if(doll.parts.has(BodypartSlot.Penis)): # doll1 and doll3 is the dom for this scene
		theParts = doll.parts[BodypartSlot.Penis].meshesThatUpdateMaterial
	elif(GlobalRegistry.getCharacter(doll.savedCharacterID).getInventory().getEquippedItem(InventorySlot.Strapon) != null && not doll.parts.has("strapon")):
		var _blank = MeshInstance.new()
		_blank.material_override = SpatialMaterial.new()
		theParts = [_blank, _blank]
	elif(doll.parts.has("strapon")):
		theParts = [doll.parts["strapon"].get_children()[1], doll.parts["strapon"].get_children()[1]]
	else:
		printerr("wtf where is the penis")
		return	if(doll3.parts.has(BodypartSlot.Penis)): # doll1 and doll3 is the dom for this scene
		thePart3 = doll3.parts[BodypartSlot.Penis]
		
	doll2.parts[BodypartSlot.Body].get_children()[-1].visible = true
#	doll.parts[BodypartSlot.Body].get_children()[-1].visible = true

	if(animID == "tease"):
		state_machine.travel("SexTrainTease_1-loop")
		state_machine2.travel("SexTrainTease_2-loop")
		state_machine3.travel("SexTrainTease_3-loop")
		doll2.parts[BodypartSlot.Body].get_children()[-1].visible = false
		for idx in [0,1]: # get the mesh, there's 4 meshes for usual penis
			var themesh = theParts[idx] #mesh 1 is the penis, 2 is the condom sprite. 3 and 4 are for non-erect and caged versions, so we skip
			var mat = themesh.get_active_material(0) # need to modify the material, assume first material because nothing in the game uses more than 1
			mat.render_priority = 0 # the masking layer is rendered at -1, by rendering at 0 it's in front of the mask and is visible
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = 0
	if(animID == "inside"):
		state_machine.travel("SexTrainInside_1-loop")
		state_machine2.travel("SexTrainInside_2-loop")
		state_machine3.travel("SexTrainInside_3-loop")
#		doll.clampPenisScale(0.8, 1.0)
		for idx in [0,1]: 
			var themesh = theParts[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2
	if(animID == "sex"):
		state_machine.travel("SexTrain_1-loop")
		state_machine2.travel("SexTrain_2-loop")
		state_machine3.travel("SexTrain_3-loop")
#		doll.clampPenisScale(0.8, 1.0)
		for idx in [0,1]: 
			var themesh = theParts[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2
	if(animID == "fast"):
		state_machine.travel("SexTrainFast_1-loop")
		state_machine2.travel("SexTrainFast_2-loop")
		state_machine3.travel("SexTrainFast_3-loop")
#		doll.clampPenisScale(0.8, 1.0)
		for idx in [0,1]: 
			var themesh = theParts[idx]
			var mat = themesh.get_active_material(0) 
			mat.render_priority = -2
			themesh = thePart3.meshesThatUpdateMaterial[idx]
			mat = themesh.get_active_material(0)
			mat.render_priority = -2



func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	var thirdDoll = "pc"
	if(_args.has("npc2")):
		thirdDoll = _args["npc2"]
		
	if(doll.getCharacterID() != firstDoll || doll2.getCharacterID() != secondDoll || doll3.getCharacterID() != thirdDoll):
		return false
	return true

func getSupportedStates():
	return ["tease", "inside", "sex", "fast"]

func getVarNpcs():
	return ["pc", "npc", "npc2"]
