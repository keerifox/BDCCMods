extends MeshInstance
class_name MeshInstanceWithPattern

export var pattern_start:Vector2
export var pattern_size:Vector2 = Vector2(1.0, 1.0)
export(String, "head", "hair", "ears", "horns", "body", "arms", "breasts", "penis", "vagina", "anus", "tail", "legs", "CUSTOM") var bodypartSlot:String
export var bodypartSlotCustom:String = "" # Set the bodypartSlot to CUSTOM first
export(Texture) var customOverlay = null
export(Texture) var customSkinPattern = null
export(Texture) var customAlbedo = null
export(bool) var showCumLayer = true
export(Vector2) var cumLayerScale = Vector2(1.0, 1.0)
export(String) var custonSkinVariant = ""
var partRef
var fancyMaterial
var defaultOverlay = preload("res://Player/Player3D/Skins/defaultoverlay.png")

var materialWithSkin = preload("res://Player/Player3D/Skins/MaterialForPartWithSkin.tres")

export(bool) var supportsWritings = false
var writingsHandler
var writingZoneInfos:Dictionary = {}
var albedoTextureSize:Vector2

const BulgeUtils = preload("res://Player/Player3D/Bulge/BulgeUtils.gd")
const BulgeSolver = preload("res://Player/Player3D/Bulge/BulgeSolver.gd")
const BULGE_SLOTS = 2
const BULGE_DISABLED_CLIP = 2.0
# How far the body cutout is widened at load, in rest units, purely to give bulges room. The
# extra geometry is transparent, so this costs nothing visually.
const BULGE_MARGIN_PAD:float = 0.6

var uvFit = null # rest space -> UV space transform of this mesh, see BulgeUtils
var hasBulges:bool = false
var hasShaftClip:bool = false

func getPart():
	if(partRef == null):
		return null
	return partRef.get_ref()

func getDoll():
	var thePart = getPart()
	if(thePart == null):
		return null
	return thePart.getDoll()

func _ready():
	if(!OPTIONS.shouldUseAdvancedShaders()):
		return
	
	var albedoTexture:Texture
	if(customAlbedo != null):
		albedoTexture = customAlbedo
	else:
		var current_material = get_surface_material(0)
		albedoTexture = current_material.albedo_texture
	if(albedoTexture):
		albedoTextureSize = albedoTexture.get_size()
	
	
	fancyMaterial = materialWithSkin.duplicate()
	if(customSkinPattern == null):
		fancyMaterial.set_shader_param("pattern_start", pattern_start / 2048.0 * 256.0)
		fancyMaterial.set_shader_param("pattern_size", pattern_size / 2048.0 * 256.0)
		fancyMaterial.set_shader_param("cum_scale", Vector2(5.0, 5.0) * cumLayerScale)
	else:
		fancyMaterial.set_shader_param("pattern_start", pattern_start)
		fancyMaterial.set_shader_param("pattern_size", pattern_size)
		fancyMaterial.set_shader_param("cum_scale", Vector2(0.5, 0.5) * cumLayerScale)
	fancyMaterial.set_shader_param("texture_albedo", albedoTexture)
	if(customOverlay != null):
		fancyMaterial.set_shader_param("texture_customOverlay", customOverlay)
	fancyMaterial.set_shader_param("random_shift", RNG.randf_range(0.0, 1000.0))
	set_surface_material(0, fancyMaterial)

	# The body carries every crotch bulge and is the one cutout whose margin runs out, so it
	# gets a skirt of extra geometry to grow into. One part, shared by every character in the
	# game, so this is cheap and happens once: the expanded mesh is cached on the original.
	if(bodypartSlot == "body" && BULGE_MARGIN_PAD > 0.0):
		var expanded = BulgeUtils.getExpandedMesh(mesh, BULGE_MARGIN_PAD)
		if(expanded != null && expanded != mesh):
			mesh = expanded
			set_surface_material(0, fancyMaterial)

	uvFit = BulgeUtils.getUVFit(mesh)
	if(uvFit != null):
		fancyMaterial.set_shader_param("bulge_aspect", uvFit["aspect"])

	# The bulge solver is ticked from here rather than from the stage scene: overriding
	# BaseStageScene3D.gd from a mod has no effect in an exported game, while this file does get
	# replaced. One doll's body mesh drives the whole scene, once per frame.
	set_process(getFinalBodypartSlot() == "body")
	
	if(supportsWritings && OPTIONS.isVisibleBodywritingsEnabled()):
		for child in get_children():
			if(child is WritingZoneInfoNode):
				writingZoneInfos[child.zone] = child
		
		writingsHandler = preload("res://Player/Player3D/WritingsHandler/WritingsHandler.tscn").instance()
		add_child(writingsHandler)
		writingsHandler.setData(self)

func _process(_delta):
	var theDoll = getDoll()
	if(theDoll == null || !is_instance_valid(theDoll)):
		return
	var stageScene = theDoll.get_parent()
	if(stageScene == null || !stageScene.has_method("getDolls")):
		return
	# Every doll in the scene has a body mesh, so the tick is stamped on the scene to keep it
	# at one solve per frame no matter how many dolls are in there.
	var frame:int = Engine.get_idle_frames()
	if(stageScene.has_meta("bulgeTickFrame") && stageScene.get_meta("bulgeTickFrame") == frame):
		return
	stageScene.set_meta("bulgeTickFrame", frame)

	BulgeSolver.solve(stageScene.getDolls())

func updateMaterial():
	if(!OPTIONS.shouldUseAdvancedShaders()):
		return
	if(writingsHandler):
		writingsHandler.triggerUpdate()
	
	var theDoll = getDoll()
	if(theDoll != null):
		if(showCumLayer && theDoll.getCumAmount() > 0):
			fancyMaterial.set_shader_param("cum_transparency", 1.0)
			fancyMaterial.set_shader_param("cum_amount", theDoll.getCumAmount())
			fancyMaterial.set_shader_param("cum_color", theDoll.getCumColor())
		else:
			fancyMaterial.set_shader_param("cum_transparency", 0.0)
			fancyMaterial.set_shader_param("cum_amount", 0)
		
		var skinData = theDoll.getSkinDataByID(getFinalBodypartSlot())
		if(skinData != null):
			#fancyMaterial = materialWithSkin.duplicate()
			if(skinData.has("partskin") && skinData.has("partid")):
				var theSkin = GlobalRegistry.getPartSkin(skinData["partid"], skinData["partskin"])
				if(theSkin != null):
					var thePatternTexture = theSkin.getPatternTexture()
					if(thePatternTexture != null):
						if(thePatternTexture is Dictionary):
							if(thePatternTexture.has(custonSkinVariant)):
								fancyMaterial.set_shader_param("texture_pattern", thePatternTexture[custonSkinVariant])
							elif(customSkinPattern != null):
								fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
						else:
							fancyMaterial.set_shader_param("texture_pattern", thePatternTexture)
					elif(customSkinPattern != null):
						fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
			elif(customSkinPattern != null):
				fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
			elif(skinData.has("skin")):
				var theSkin = GlobalRegistry.getSkin(skinData["skin"])
				if(theSkin != null):
					fancyMaterial.set_shader_param("texture_pattern", theSkin.getPatternTexture())
			
			if(skinData.has("r")):
				fancyMaterial.set_shader_param("pattern_red_color", skinData["r"])
			else:
				fancyMaterial.set_shader_param("pattern_red_color", Color.white)
			if(skinData.has("g")):
				fancyMaterial.set_shader_param("pattern_green_color", skinData["g"])
			else:
				fancyMaterial.set_shader_param("pattern_green_color", Color.white)
			if(skinData.has("b")):
				fancyMaterial.set_shader_param("pattern_blue_color", skinData["b"])
			else:
				fancyMaterial.set_shader_param("pattern_blue_color", Color.white)
			#print(skinData)

func updateFacing():
	if(writingsHandler):
		writingsHandler.updateFacing()

func getFinalBodypartSlot() -> String:
	if(bodypartSlot == "CUSTOM"):
		return bodypartSlotCustom
	return bodypartSlot

func supportsBulges() -> bool:
	return fancyMaterial != null && uvFit != null

# Places one bulge. The segment is given in rest space (the skeleton's bind pose, which is
# also the space the UVs are glued to) and gets converted to UV space here.
# spread and amplitude are in rest units, shade is 0..1-ish.
func setBulge(index:int, restA:Vector2, restB:Vector2, spread:float, amplitude:float, shade:float, halfLength:float = 0.0):
	if(!supportsBulges() || index < 0 || index >= BULGE_SLOTS):
		return
	var uvA:Vector2 = BulgeUtils.restToUV(uvFit, restA)
	var uvB:Vector2 = BulgeUtils.restToUV(uvFit, restB)
	fancyMaterial.set_shader_param("bulge_seg"+str(index), Plane(uvA.x, uvA.y, uvB.x, uvB.y))
	fancyMaterial.set_shader_param("bulge_par"+str(index), Plane(spread, amplitude, shade, halfLength))
	hasBulges = true

func clearBulges():
	if(!hasBulges || fancyMaterial == null):
		return
	for i in range(BULGE_SLOTS):
		fancyMaterial.set_shader_param("bulge_par"+str(i), Plane(0.0, 0.0, 0.0, 0.0))
	hasBulges = false

# Hides everything on this mesh past the given rest space x. Shafts point towards -x, so
# that means everything deeper than the entry point disappears.
func setShaftClipAtRestX(restX:float, feather:float = 0.006):
	if(!supportsBulges()):
		return
	var restMin:Vector2 = uvFit["restMin"]
	var restMax:Vector2 = uvFit["restMax"]
	if(restX <= restMin.x):
		clearShaftClip()
		return
	var midRestY:float = (restMin.y + restMax.y) * 0.5
	var clipUV:Vector2 = BulgeUtils.restToUV(uvFit, Vector2(restX, midRestY))
	var rowU:Vector3 = uvFit["u"]
	fancyMaterial.set_shader_param("shaft_clip", clipUV.x)
	fancyMaterial.set_shader_param("shaft_clip_dir", -1.0 if rowU.x >= 0.0 else 1.0)
	fancyMaterial.set_shader_param("shaft_clip_feather", feather)
	hasShaftClip = true

func clearShaftClip():
	if(!hasShaftClip || fancyMaterial == null):
		return
	fancyMaterial.set_shader_param("shaft_clip", BULGE_DISABLED_CLIP)
	hasShaftClip = false
