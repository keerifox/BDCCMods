extends Reference

# Helpers for the bulge/insertion deformation system.
#
# All the doll parts are flat cutout meshes that live in the xy plane of the skeleton's
# bind pose (the 'rest space'). For a flat mesh the mapping from rest space to UV space
# is affine, so a least squares fit gives us an exact enough rest->UV transform.
# That lets us place a deformation in UV space (where the shader can warp the texture at
# pixel resolution) starting from a world space position, without touching the geometry.

const META_FIT = "bdccBulgeUVFit"
# Clip only shader for shaft cutouts that never get the skin shader. See ShaftClip.shader.
const SHAFT_CLIP_SHADER = preload("res://Player/Player3D/Bulge/ShaftClip.shader")

# Returns a Dictionary or null if the mesh can't be fitted:
# {
#   u = Vector3(a, b, c),  # UV.x = a*restX + b*restY + c
#   v = Vector3(a, b, c),  # UV.y = a*restX + b*restY + c
#   aspect = Vector2,      # multiply an UV coord by this to get (roughly) world units
#   restMin = Vector2, restMax = Vector2,
#   error = float,         # max fit error, in UV units
# }
static func getUVFit(mesh:Mesh):
	if(mesh == null):
		return null
	if(mesh.has_meta(META_FIT)):
		var cached = mesh.get_meta(META_FIT)
		if(cached is Dictionary):
			return cached
		return null # A previous attempt already failed on this mesh

	var fit = calculateUVFit(mesh)
	mesh.set_meta(META_FIT, fit if fit != null else false)
	return fit

static func calculateUVFit(mesh:Mesh):
	if(mesh.get_surface_count() <= 0):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays.size() <= Mesh.ARRAY_TEX_UV):
		return null
	var verts = arrays[Mesh.ARRAY_VERTEX]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	if(verts == null || uvs == null || verts.size() < 3 || uvs.size() != verts.size()):
		return null

	# Normal equations for [restX, restY, 1] -> UV.x and -> UV.y
	var A := [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
	var bu := [0.0, 0.0, 0.0]
	var bv := [0.0, 0.0, 0.0]
	var restMin := Vector2(99999.0, 99999.0)
	var restMax := Vector2(-99999.0, -99999.0)

	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var uv:Vector2 = uvs[i]
		var p := [vert.x, vert.y, 1.0]
		for r in range(3):
			for c in range(3):
				A[r][c] += p[r] * p[c]
			bu[r] += p[r] * uv.x
			bv[r] += p[r] * uv.y
		restMin.x = min(restMin.x, vert.x)
		restMin.y = min(restMin.y, vert.y)
		restMax.x = max(restMax.x, vert.x)
		restMax.y = max(restMax.y, vert.y)

	var mu = solve3(A, bu)
	var mv = solve3(A, bv)
	if(mu == null || mv == null):
		return null

	var rowU := Vector3(mu[0], mu[1], mu[2])
	var rowV := Vector3(mv[0], mv[1], mv[2])

	var maxError := 0.0
	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var predicted := Vector2(
			rowU.x * vert.x + rowU.y * vert.y + rowU.z,
			rowV.x * vert.x + rowV.y * vert.y + rowV.z)
		maxError = max(maxError, predicted.distance_to(uvs[i]))

	# How many world units one UV unit covers on each axis. The fit is near diagonal on
	# every doll part (the cross terms are ~1% of the main ones) so this is enough.
	var scaleU:float = abs(rowU.x)
	var scaleV:float = abs(rowV.y)
	if(scaleU < 0.000001 || scaleV < 0.000001):
		return null

	return {
		"u": rowU,
		"v": rowV,
		"aspect": Vector2(1.0 / scaleU, 1.0 / scaleV),
		"restMin": restMin,
		"restMax": restMax,
		"error": maxError,
	}

static func restToUV(fit:Dictionary, restPos:Vector2) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	return Vector2(
		rowU.x * restPos.x + rowU.y * restPos.y + rowU.z,
		rowV.x * restPos.x + rowV.y * restPos.y + rowV.z)

# Gauss-Jordan on a 3x3 system. Returns null when the system is degenerate.
static func solve3(A:Array, b:Array):
	var m := [
		[A[0][0], A[0][1], A[0][2], b[0]],
		[A[1][0], A[1][1], A[1][2], b[1]],
		[A[2][0], A[2][1], A[2][2], b[2]],
	]
	for col in range(3):
		var pivot := col
		for r in range(col + 1, 3):
			if(abs(m[r][col]) > abs(m[pivot][col])):
				pivot = r
		var swap = m[col]
		m[col] = m[pivot]
		m[pivot] = swap

		var diag:float = m[col][col]
		if(abs(diag) < 0.000000001):
			return null
		for c in range(col, 4):
			m[col][c] /= diag
		for r in range(3):
			if(r == col):
				continue
			var factor:float = m[r][col]
			for c in range(col, 4):
				m[r][c] -= factor * m[col][c]
	return [m[0][3], m[1][3], m[2][3]]

# Rest space (bind pose) transform of a bone, walking up the parent chain.
# Same math as MyBoneAttachment.getAllRestTransformsForBone(), kept here so the bulge code
# doesn't need an attachment node to do it.
static func getBoneRestGlobal(skeleton:Skeleton, boneIdx:int) -> Transform:
	var result := Transform.IDENTITY
	if(boneIdx < 0):
		return result
	var chain := []
	var idx := boneIdx
	while(idx >= 0):
		chain.append(skeleton.get_bone_rest(idx))
		idx = skeleton.get_bone_parent(idx)
	chain.invert()
	for restTransform in chain:
		result = result * restTransform
	return result

# Takes a world position and returns where that position sits in the skeleton's rest space,
# by going through the given bone. Only correct for points that move with that bone, which
# is exactly what we want: the crotch follows Hips, the throat follows Head, and so on.
static func worldToRest(skeleton:Skeleton, boneName:String, worldPos:Vector3) -> Vector3:
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return worldPos
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	var boneLocal:Vector3 = posedGlobal.affine_inverse().xform(worldPos)
	return getBoneRestGlobal(skeleton, boneIdx).xform(boneLocal)

# Same as restToWorld but for a direction, so mirrored dolls (the doll node gets a negative
# scale when it faces the other way) come out mirrored too.
static func restDirToWorld(skeleton:Skeleton, boneName:String, restDir:Vector3) -> Vector3:
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return restDir
	var boneLocal:Vector3 = getBoneRestGlobal(skeleton, boneIdx).affine_inverse().basis.xform(restDir)
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	return posedGlobal.basis.xform(boneLocal).normalized()

# The other direction: takes a point in rest space and returns where the given bone has
# moved it to in the world. Used to find where a shaft's tip currently is.
static func restToWorld(skeleton:Skeleton, boneName:String, restPos:Vector3) -> Vector3:
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return restPos
	var boneLocal:Vector3 = getBoneRestGlobal(skeleton, boneIdx).affine_inverse().xform(restPos)
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	return posedGlobal.xform(boneLocal)

# --- shaft thickness profile ---------------------------------------------------------------
# How thick the shaft is along its length, measured from its own artwork rather than assumed,
# so a knot or an equine flare makes the bulge react to it. Values are relative to the shaft's
# median thickness: 1.0 is "as thick as usual", 1.4 is a knot. Index 0 is the base, the last
# index is the tip. Cached on the mesh, since artwork doesn't change.
const PROFILE_BINS:int = 16
const PROFILE_SAMPLES:int = 48
const PROFILE_ALPHA:float = 0.35
# Fraction of the length at the base that the profile ignores, because that is sheath and balls
# rather than shaft. Index 0 of the profile is therefore this far along, not at the very root.
const PROFILE_SKIP_BASE:float = 0.3
# Columns used to find where the artwork actually starts and ends along the quad.
const PROFILE_COLUMNS:int = 48

static func getShaftProfile(meshInstance) -> Array:
	if(meshInstance == null || fitOf(meshInstance) == null):
		return []
	# Cached on the TEXTURE, not the mesh: every cock cutout reuses the same quad, so caching
	# on the mesh handed out the first shaft's measurements to every other shaft in the game.
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null):
		return []
	if(texture.has_meta("bulgeShaftProfile")):
		return texture.get_meta("bulgeShaftProfile")

	var image:Image = texture.get_data()
	if(image == null):
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		return []

	var fit:Dictionary = fitOf(meshInstance)
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var width:int = image.get_width()
	var height:int = image.get_height()
	image.lock()

	# The quads carry a lot of transparent padding, so first find where the shaft is actually
	# drawn. Measuring across the whole quad instead left half the bins empty and dragged the
	# average thickness down to nonsense.
	var drawnBase:float = restMax.x
	var drawnTip:float = restMin.x
	var found:bool = false
	for column in range(PROFILE_COLUMNS):
		var x:float = lerp(restMax.x, restMin.x, (column + 0.5) / float(PROFILE_COLUMNS))
		if(columnThickness(image, fit, x, restMin.y, restMax.y, width, height) <= 0.0):
			continue
		if(!found):
			drawnBase = x
			found = true
		drawnTip = x
	if(!found):
		image.unlock()
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		return []

	var profile:Array = []
	for bin in range(PROFILE_BINS):
		# Skip the first stretch: sheath and balls live down there and are far thicker than
		# the shaft, which otherwise makes every cock read as "knot everywhere".
		var t:float = PROFILE_SKIP_BASE + (1.0 - PROFILE_SKIP_BASE) * (bin + 0.5) / float(PROFILE_BINS)
		var x:float = lerp(drawnBase, drawnTip, t)
		profile.append(columnThickness(image, fit, x, restMin.y, restMax.y, width, height) * 0.5)
	image.unlock()

	# Normalise on the mean, and take that mean as the shaft's radius: this is the number the
	# solver scales the bulge by, so it has to be the shaft's real half thickness in rest units.
	var total:float = 0.0
	for value in profile:
		total += value
	var mean:float = total / float(max(profile.size(), 1))
	if(mean <= 0.0001):
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		return []
	texture.set_meta("bulgeShaftGirth", mean)
	texture.set_meta("bulgeShaftSpan", Vector2(drawnBase, drawnTip))
	for i in range(profile.size()):
		profile[i] = profile[i] / mean
	texture.set_meta("bulgeShaftProfile", profile)
	return profile

# Where the artwork starts and ends across one column of the shaft, in rest space y, or a zero
# span when that column is empty. Taking the distance from the quad centre instead measured the
# shaft's offset within its quad on top of its actual thickness.
static func columnExtent(image:Image, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> Vector2:
	var lowest:float = 0.0
	var highest:float = 0.0
	var found:bool = false
	for sample in range(PROFILE_SAMPLES):
		var y:float = lerp(minY, maxY, (sample + 0.5) / float(PROFILE_SAMPLES))
		var uv:Vector2 = restToUV(fit, Vector2(x, y))
		if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
			continue
		var px:int = int(clamp(uv.x * (width - 1), 0, width - 1))
		var py:int = int(clamp(uv.y * (height - 1), 0, height - 1))
		if(image.get_pixel(px, py).a >= PROFILE_ALPHA):
			if(!found):
				lowest = y
				found = true
			highest = y
	if(!found):
		return Vector2.ZERO
	return Vector2(lowest, highest)

static func getShaftGirth(meshInstance) -> float:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftGirth")):
		return 0.0
	return texture.get_meta("bulgeShaftGirth")

static func getAlbedoImage(meshInstance):
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null):
		return null
	return texture.get_data()

# The texture a part is currently drawn with. Everything measured off the artwork is cached on
# it rather than on the mesh, because all the cutouts share their quads.
static func getAlbedoTexture(meshInstance):
	# get() rather than a field read: a rigged strapon's cutouts are plain MeshInstances, so
	# they have no customAlbedo at all.
	var texture:Texture = meshInstance.get("customAlbedo")
	# Advanced skins replace the part's SpatialMaterial with a duplicated ShaderMaterial, so
	# the texture has to be read off whichever of the two this mesh currently carries.
	if(texture == null):
		for material in [meshInstance.material_override, meshInstance.get_surface_material(0)]:
			if(material == null):
				continue
			if(material is ShaderMaterial):
				texture = material.get_shader_param("texture_albedo")
			elif(material is SpatialMaterial):
				texture = material.albedo_texture
			if(texture != null):
				break
	return texture

# How thick the inserted stretch is on average, as a factor on the shaft's median thickness.
# fromT and toT run 0 at the base to 1 at the tip. Average, not maximum: taking the widest
# point made one knot decide the size for the whole thrust, so every cock looked the same.
static func averageProfileBetween(profile:Array, fromT:float, toT:float) -> float:
	if(profile.empty()):
		return 1.0
	var last:int = profile.size() - 1
	# The profile starts PROFILE_SKIP_BASE along the shaft, so shift the range into its space.
	var span:float = max(1.0 - PROFILE_SKIP_BASE, 0.001)
	var lowT:float = clamp((min(fromT, toT) - PROFILE_SKIP_BASE) / span, 0.0, 1.0)
	var highT:float = clamp((max(fromT, toT) - PROFILE_SKIP_BASE) / span, 0.0, 1.0)
	var lowIndex:int = int(floor(lowT * last))
	var highIndex:int = int(ceil(highT * last))
	var total:float = 0.0
	var count:int = 0
	for i in range(lowIndex, highIndex + 1):
		total += profile[i]
		count += 1
	if(count <= 0):
		return 1.0
	return total / float(count)

# --- silhouette test ------------------------------------------------------------------------
# A coarse alpha mask of a cutout, so we can ask "is this point inside the drawn body?".
# Along-the-shaft maths cannot tell a cock pressed against a hole from one inside it: the
# orifice anchors sit under the skin, so a shaft merely rubbing against the body still reads
# as inserted. Checking the tip against the receiver's own silhouette settles it.
const MASK_SIZE:int = 64
const MASK_ALPHA:float = 0.35

static func getAlphaMask(meshInstance):
	if(meshInstance == null || fitOf(meshInstance) == null):
		return null
	var cacheOn:Texture = getAlbedoTexture(meshInstance)
	if(cacheOn == null):
		return null
	if(cacheOn.has_meta("bulgeAlphaMask")):
		var cached = cacheOn.get_meta("bulgeAlphaMask")
		return cached if cached is Dictionary else null

	var image:Image = getAlbedoImage(meshInstance)
	if(image == null):
		cacheOn.set_meta("bulgeAlphaMask", false)
		return null

	var width:int = image.get_width()
	var height:int = image.get_height()
	image.lock()
	var bits:PoolByteArray = PoolByteArray()
	for y in range(MASK_SIZE):
		var py:int = int(clamp((y + 0.5) / MASK_SIZE * height, 0, height - 1))
		for x in range(MASK_SIZE):
			var px:int = int(clamp((x + 0.5) / MASK_SIZE * width, 0, width - 1))
			bits.append(1 if image.get_pixel(px, py).a >= MASK_ALPHA else 0)
	image.unlock()

	var mask:Dictionary = {"size": MASK_SIZE, "bits": bits}
	cacheOn.set_meta("bulgeAlphaMask", mask)
	return mask

# True when the rest space point lands on drawn pixels of that cutout. Unknown counts as true,
# so a mesh we can't read never blocks the effect.
static func isRestPointOpaque(meshInstance, restPos:Vector2) -> bool:
	var mask = getAlphaMask(meshInstance)
	if(mask == null):
		return true
	var uv:Vector2 = restToUV(fitOf(meshInstance), restPos)
	if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
		return false
	var size:int = mask["size"]
	var x:int = int(clamp(uv.x * size, 0, size - 1))
	var y:int = int(clamp(uv.y * size, 0, size - 1))
	var bits:PoolByteArray = mask["bits"]
	return bits[y * size + x] != 0


# How much empty room a cutout has in front of its silhouette, in rest units. This is the hard
# limit on how far the shader may push the alpha edge outwards: past it there is no artwork
# left to draw and the body ends up sliced off flat. Measured rather than assumed, so a mesh
# with a generous margin gets a bigger bulge and a tight one doesn't break.
const MARGIN_ROWS:int = 24

static func getFrontMargin(meshInstance) -> float:
	if(meshInstance == null || fitOf(meshInstance) == null):
		return 0.0
	var cacheOn:Texture = getAlbedoTexture(meshInstance)
	if(cacheOn == null):
		return 0.0
	if(cacheOn.has_meta("bulgeFrontMargin")):
		return cacheOn.get_meta("bulgeFrontMargin")
	if(getAlphaMask(meshInstance) == null):
		return 0.0

	var fit:Dictionary = fitOf(meshInstance)
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var steps:int = 40
	var margins:Array = []
	for row in range(MARGIN_ROWS):
		var y:float = lerp(restMin.y, restMax.y, (row + 0.5) / float(MARGIN_ROWS))
		# The dolls face -x, so walk in from the front edge until the artwork starts.
		for step in range(steps + 1):
			var x:float = lerp(restMin.x, restMax.x, float(step) / float(steps))
			if(isRestPointOpaque(meshInstance, Vector2(x, y))):
				margins.append(x - restMin.x)
				break
	if(margins.empty()):
		cacheOn.set_meta("bulgeFrontMargin", 0.0)
		return 0.0
	margins.sort()
	# Median, so a stray thin row doesn't decide it for the whole body.
	var margin:float = margins[int(margins.size() / 2)]
	cacheOn.set_meta("bulgeFrontMargin", margin)
	return margin


# Where the shaft's artwork actually starts and ends along the quad, as rest space x: x of the
# base end, then x of the tip end. Only the debug tooling needs this.
static func getShaftSpan(meshInstance) -> Vector2:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftSpan")):
		return Vector2.ZERO
	return texture.get_meta("bulgeShaftSpan")

# Thickness of the artwork across one column of the shaft, in rest units.
static func columnThickness(image:Image, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> float:
	var extent:Vector2 = columnExtent(image, fit, x, minY, maxY, width, height)
	return max(extent.y - extent.x, 0.0)

# --- margin expansion -----------------------------------------------------------------------
# The shader grows a body by dragging its alpha edge outwards, which stops dead at the edge of
# the cutout's geometry: past it there are no fragments to shade, so a big bulge gets sliced
# off flat. This widens that budget at load time by sewing a skirt of extra triangles around
# the mesh's boundary. The original vertices don't move, so the artwork is untouched; the new
# ones carry UVs that continue past the texture, which the shader draws as transparent.
# Only the body cutout needs it, and there is exactly one body part in the game.
const META_EXPANDED = "bdccBulgeExpandedMesh"

static func getExpandedMesh(mesh:Mesh, pad:float):
	if(mesh == null || pad <= 0.0):
		return mesh
	if(mesh.has_meta(META_EXPANDED)):
		var cached = mesh.get_meta(META_EXPANDED)
		return cached if cached is Mesh else mesh

	var built = buildExpandedMesh(mesh, pad)
	mesh.set_meta(META_EXPANDED, built if built != null else false)
	return built if built != null else mesh

static func buildExpandedMesh(mesh:Mesh, pad:float):
	if(mesh.get_surface_count() <= 0):
		return null
	var fit = getUVFit(mesh)
	if(fit == null):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	var verts:PoolVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var uvs:PoolVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices:PoolIntArray = arrays[Mesh.ARRAY_INDEX]
	if(verts.size() == 0 || uvs.size() != verts.size() || indices.size() < 3):
		return null

	# An edge that belongs to a single triangle is on the outline.
	var edgeUse:Dictionary = {}
	for i in range(0, indices.size(), 3):
		for corner in range(3):
			var a:int = indices[i + corner]
			var b:int = indices[i + (corner + 1) % 3]
			var key:String = str(min(a, b)) + "_" + str(max(a, b))
			edgeUse[key] = edgeUse.get(key, 0) + 1

	var centre:Vector2 = Vector2.ZERO
	for vert in verts:
		centre += Vector2(vert.x, vert.y)
	centre /= float(verts.size())

	var newVerts:PoolVector3Array = PoolVector3Array(verts)
	var newUVs:PoolVector2Array = PoolVector2Array(uvs)
	var newIndices:PoolIntArray = PoolIntArray(indices)
	var newNormals = arrays[Mesh.ARRAY_NORMAL]
	var newBones = arrays[Mesh.ARRAY_BONES]
	var newWeights = arrays[Mesh.ARRAY_WEIGHTS]
	var skirtFor:Dictionary = {} # original vertex -> its skirt copy

	for key in edgeUse:
		if(edgeUse[key] != 1):
			continue
		var parts:Array = key.split("_")
		for side in range(2):
			var index:int = int(parts[side])
			if(skirtFor.has(index)):
				continue
			var source:Vector3 = verts[index]
			var outward:Vector2 = (Vector2(source.x, source.y) - centre)
			if(outward.length() < 0.0001):
				continue
			var moved:Vector3 = source + Vector3(outward.normalized().x, outward.normalized().y, 0.0) * pad
			skirtFor[index] = newVerts.size()
			newVerts.push_back(moved)
			# Same affine the rest of the system uses, so the skirt's UVs simply continue.
			newUVs.push_back(restToUV(fit, Vector2(moved.x, moved.y)))
			if(newNormals != null && newNormals.size() > index):
				newNormals.push_back(newNormals[index])
			# Skinning is inherited from the vertex each skirt point grew out of, so the new
			# geometry follows the body instead of hanging in place.
			if(newBones != null && newBones.size() >= (index + 1) * 4):
				for slot in range(4):
					newBones.push_back(newBones[index * 4 + slot])
					newWeights.push_back(newWeights[index * 4 + slot])

	if(skirtFor.empty()):
		return null

	for key in edgeUse:
		if(edgeUse[key] != 1):
			continue
		var parts2:Array = key.split("_")
		var a2:int = int(parts2[0])
		var b2:int = int(parts2[1])
		if(!skirtFor.has(a2) || !skirtFor.has(b2)):
			continue
		var a3:int = skirtFor[a2]
		var b3:int = skirtFor[b2]
		# The material draws both sides, so the winding here doesn't matter.
		newIndices.push_back(a2); newIndices.push_back(b2); newIndices.push_back(b3)
		newIndices.push_back(a2); newIndices.push_back(b3); newIndices.push_back(a3)

	var out:Array = []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = newVerts
	out[Mesh.ARRAY_TEX_UV] = newUVs
	out[Mesh.ARRAY_INDEX] = newIndices
	if(newNormals != null):
		out[Mesh.ARRAY_NORMAL] = newNormals
	if(newBones != null):
		out[Mesh.ARRAY_BONES] = newBones
		out[Mesh.ARRAY_WEIGHTS] = newWeights

	var expanded:ArrayMesh = ArrayMesh.new()
	expanded.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out)
	return expanded


# --- cutouts that aren't MeshInstanceWithPattern -------------------------------------------
# Rigged strapons reach the doll through the clothing pipeline, so they end up as plain
# MeshInstances with a SpatialMaterial: no skin shader, and no uvFit field of their own. They
# are still flat cutouts skinned to the same Penis bones as a real cock, so everything measured
# off the artwork works on them as soon as the fit is looked up from the mesh instead.

# The rest->UV fit of a cutout, wherever it keeps it. MeshInstanceWithPattern computes it once
# in _ready and caches it on itself; anything else falls back to the fit cached on the mesh.
static func fitOf(meshInstance):
	if(meshInstance == null):
		return null
	var own = meshInstance.get("uvFit")
	if(own != null):
		return own
	return getUVFit(meshInstance.mesh)

# Same job as MeshWithPattern.setShaftClipAtRestX, for a mesh that has no skin shader to set
# params on. The clip material goes in as material_override so the item's own material, which
# is what the dye path writes to, is left alone: clearing the clip restores the original look
# exactly by dropping the override.
static func setPlainShaftClip(meshInstance, restX:float, feather:float = 0.006) -> void:
	var fit = fitOf(meshInstance)
	if(fit == null):
		return
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	if(restX <= restMin.x):
		clearPlainShaftClip(meshInstance)
		return
	var material:ShaderMaterial = getPlainClipMaterial(meshInstance)
	if(material == null):
		return
	var midRestY:float = (restMin.y + restMax.y) * 0.5
	var clipUV:Vector2 = restToUV(fit, Vector2(restX, midRestY))
	var rowU:Vector3 = fit["u"]
	material.set_shader_param("shaft_clip", clipUV.x)
	material.set_shader_param("shaft_clip_dir", -1.0 if rowU.x >= 0.0 else 1.0)
	material.set_shader_param("shaft_clip_feather", feather)

static func clearPlainShaftClip(meshInstance) -> void:
	if(meshInstance == null || !is_instance_valid(meshInstance)):
		return
	if(isPlainClipMaterial(meshInstance.material_override)):
		meshInstance.material_override = null

static func isPlainClipMaterial(material) -> bool:
	return material is ShaderMaterial && material.shader == SHAFT_CLIP_SHADER

# The override has to carry the albedo of whatever the mesh is drawn with right now, so a dyed
# strapon still shows its colour while it's clipped. Re-read every time rather than cached: the
# dye can change between two frames and this is two property reads.
static func getPlainClipMaterial(meshInstance):
	var source = meshInstance.get_surface_material(0)
	if(source == null && meshInstance.mesh != null && meshInstance.mesh.get_surface_count() > 0):
		source = meshInstance.mesh.surface_get_material(0)
	if(!(source is SpatialMaterial)):
		return null
	var material = meshInstance.material_override
	if(!isPlainClipMaterial(material)):
		material = ShaderMaterial.new()
		material.shader = SHAFT_CLIP_SHADER
		meshInstance.material_override = material
	material.set_shader_param("texture_albedo", source.albedo_texture)
	material.set_shader_param("albedo", source.albedo_color)
	return material
