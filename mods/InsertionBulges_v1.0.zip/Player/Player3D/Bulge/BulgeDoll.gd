extends Node

# Per doll state and geometry for the bulge system.
#
# This lives in its own file on purpose. An exported game ignores a mod's copy of
# Doll3D.gd (proved on 0.3.0: MeshWithPattern.gd and Part3D.gd from the same zip do get
# replaced, Doll3D.gd does not), so nothing the bulges need may live in that file. Files at
# paths the base game doesn't have always load, so the doll gets one of these attached as a
# child instead, created by Part3D when it builds a part.

const BulgeUtils = preload("res://Player/Player3D/Bulge/BulgeUtils.gd")

const NODE_NAME:String = "BulgeHelper"

# Which bone's motion the hole follows. Used for matching only: the mouth's inward direction has
# to turn with the head or an oral pose stops registering the moment the head tilts.
const ANCHOR_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Head",
}
# Which bone's rest space the swelling is placed in. Always the body's, including for the mouth:
# a throat bulge belongs to the neck and torso, and those are drawn on the body cutout, whose
# UVs are glued to the same rest space the hips live in. Placing it in the head's space instead
# put part of the lump on the muzzle, which is not where a throat is.
const BULGE_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Hips",
}
# Where the swelling starts, for zones whose hole is not where the body reacts. A cock in a
# throat shows up from the neck down, not at the lips, so the mouth's swelling is anchored on the
# Neck bone rather than on the orifice. Measured in the bind pose: Hips y 4.33, Chest 5.04,
# Neck 6.62, Head 6.88, and the body cutout's artwork runs out just above y 7.1.
const BULGE_ORIGIN_BONE:Dictionary = {
	"mouth": "Neck",
}
# Offsets are relative to the existing bone attachments, in rest units.
const ANUS_OFFSET:Vector3 = Vector3(0.90518, -0.0511401, 0.0) # from VaginaBoneAttachment
const MOUTH_OFFSET:Vector3 = Vector3(-0.31, -0.36, 0.0) # from HeadBoneAttachment
const SHAFT_RADIUS_FACTOR:float = 0.16 # of the shaft mesh's rest height, fallback only
const TIP_EXTEND:float = 0.3 # how far past the last bone the tip sits, in segments
# Which way each hole leads into the body, in rest space. The doll faces -x, so +x is its
# back. Something can only be inserted if it's pointing roughly this way.
const ORIFICE_INWARD:Dictionary = {
	"vagina": Vector3(0.45, 0.89, 0.0),
	"anus": Vector3(-0.33, 0.94, 0.0),
	"mouth": Vector3(0.8, -0.6, 0.0),
}

var doll = null
var dirtyMeshes:Array = []
# Which hole this doll's shaft was last inserted into, per receiving doll. A long shaft passes
# close to more than one hole, so without remembering the pick the choice can flip mid thrust
# and the bulge jumps to a different height.
var zoneMemory:Dictionary = {}
# What the solver last worked out, kept so a debug readout can show real numbers.
var lastSizeResponse:float = 0.0
var lastBoneAmount:float = 0.0
# Set by a harness to declare the penis scale it wants kept. Stays 0 in the game, where the
# character is the authority. See restorePenisScale.
var scaleOverride:float = 0.0
# Whether we are currently holding the shaft bones against the animation's taper.
var taperCancelled:bool = false

# Returns the helper attached to a doll, creating it if needed.
static func forDoll(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll)):
		return null
	var existing = theDoll.get_node_or_null(NODE_NAME)
	if(existing != null):
		return existing
	var helper = load("res://Player/Player3D/Bulge/BulgeDoll.gd").new()
	helper.name = NODE_NAME
	helper.doll = theDoll
	theDoll.add_child(helper)
	return helper

func getSkeletonNode() -> Skeleton:
	return doll.getDollSkeleton().getSkeleton()

func getPatternMeshesForSlot(slot) -> Array:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var part = doll.parts[slot]
	if(!part.has_method("getPatternMeshes")):
		return []
	return part.getPatternMeshes()

func hasVisibleSlot(slot) -> bool:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return false
	return doll.parts[slot].visible


# The cutouts of one slot that could be a shaft. Body parts run the skin shader and hand theirs
# over directly. A rigged strapon is a Part3D too, but its meshes are plain MeshInstances, and
# one of them is the harness that goes round the hips, so the cock has to be picked out.
# ponytail: picked by mesh name. All eight strapons in the game say "penis" in theirs; a mod
# strapon that names its mesh something else simply doesn't bulge, which is the old behaviour.
func getShaftMeshesForSlot(slot) -> Array:
	var pattern:Array = getPatternMeshesForSlot(slot)
	if(!pattern.empty()):
		return pattern
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var found:Array = []
	collectShaftMeshes(doll.parts[slot], found)
	return found

func collectShaftMeshes(node, found:Array) -> void:
	for child in node.get_children():
		if(child is MeshInstance && child.mesh != null && "penis" in child.name.to_lower()):
			found.append(child)
		collectShaftMeshes(child, found)

# A cutout can only carry the clip if we can work out where to put the cut: the skin shader ones
# answer for themselves, a plain one needs a rest->UV fit for the clip material to aim with.
func shaftMeshUsable(themesh) -> bool:
	if(themesh.has_method("supportsBulges")):
		return themesh.supportsBulges()
	return BulgeUtils.fitOf(themesh) != null

# World space info about this doll's shaft, or null when there's nothing to insert.
# The line comes from the Penis/Penis2/Penis3 bones rather than from the mesh bounds: the
# shaft cutouts are quads with a lot of transparent padding. Going through the bones also
# picks up bending and scaling.
# { base, tip, length, radius, meshes, profile }
func getShaftInfo():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null

	var meshes:Array = []
	var radius:float = 0.0
	var profile:Array = []
	# A worn strapon hides the doll's own penis part, so these are never both visible. Stop at
	# the first slot that has something rather than mixing two shafts into one line.
	for slot in [BodypartSlot.Penis, InventorySlot.Strapon]:
		if(!hasVisibleSlot(slot)):
			continue
		for themesh in getShaftMeshesForSlot(slot):
			# The part keeps a mesh per state (hard, limp, caged...) and hides the unused ones by
			# hiding their parent, so the mesh's own visible flag isn't enough.
			if(!themesh.is_visible_in_tree() || !shaftMeshUsable(themesh)):
				continue
			meshes.append(themesh)
			if(profile.empty()):
				profile = BulgeUtils.getShaftProfile(themesh)
			# Real girth off the artwork when we can read it, mesh bounds times a fudge factor
			# only as a fallback: the padding differs per cock, so the fallback is wrong by a
			# different amount for each of them.
			var measured:float = BulgeUtils.getShaftGirth(themesh)
			if(measured > 0.0001):
				radius = max(radius, measured)
			else:
				var fit:Dictionary = BulgeUtils.fitOf(themesh)
				radius = max(radius, (fit["restMax"].y - fit["restMin"].y) * SHAFT_RADIUS_FACTOR)
		if(!meshes.empty()):
			break
	if(meshes.empty()):
		return null

	var basePos = getBoneWorldPos("Penis")
	var midPos = getBoneWorldPos("Penis2")
	var endPos = getBoneWorldPos("Penis3")
	if(basePos == null || midPos == null || endPos == null):
		return null
	# The last bone sits a bit short of the tip, so carry on in the same direction.
	var tipPos:Vector3 = endPos + (endPos - midPos) * TIP_EXTEND
	# Every cock is rigged to the same three bones, so the bones say nothing about how long
	# this particular one is drawn: an equine is far longer than a human at the same scale.
	# Measure it off the artwork instead, from the root bone to where the drawing ends.
	var drawnLength:float = getDrawnShaftLength(meshes)
	var scale:float = max(doll.rememberedPenisScale, 0.01)
	if(drawnLength > 0.01):
		tipPos = basePos + (tipPos - basePos).normalized() * drawnLength * scale

	return {
		"base": basePos,
		"tip": tipPos,
		"length": basePos.distance_to(tipPos),
		# The mesh bounds are unscaled, the drawn shaft isn't: the Penis bone carries the size.
		"radius": radius * scale,
		"meshes": meshes,
		# Thickness along the shaft, base first, relative to its median thickness.
		"profile": profile,
	}

func getDrawnShaftLength(meshes:Array) -> float:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null || meshes.empty()):
		return 0.0
	var boneIdx:int = skeleton.find_bone("Penis")
	if(boneIdx < 0):
		return 0.0
	var rootRestX:float = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin.x
	var longest:float = 0.0
	for themesh in meshes:
		var span:Vector2 = BulgeUtils.getShaftSpan(themesh)
		if(span == Vector2.ZERO):
			continue
		longest = max(longest, abs(rootRestX - span.y))
	return longest

func getBoneWorldPos(boneName:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return null
	return (skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)).origin

# World position of the given orifice ("vagina", "anus", "mouth"), or null.
func getOrificeAnchor(zone:String):
	if(zone == "mouth"):
		var headNode = doll.get_node_or_null("BoneAttachments/HeadBoneAttachment")
		if(headNode == null || !hasVisibleSlot(BodypartSlot.Head)):
			return null
		return headNode.global_transform.xform(MOUTH_OFFSET)

	var crotchNode = doll.get_node_or_null("BoneAttachments/VaginaBoneAttachment")
	if(crotchNode == null):
		return null
	if(zone == "anus"):
		return crotchNode.global_transform.xform(ANUS_OFFSET)
	if(zone == "vagina"):
		return crotchNode.global_transform.origin
	return null

# Position plus the direction the hole leads into the body, both in world space, or null.
func getOrificeInfo(zone:String):
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	return {
		"pos": anchor,
		"inward": BulgeUtils.restDirToWorld(skeleton, ANCHOR_BONE.get(zone, "Hips"), ORIFICE_INWARD.get(zone, Vector3(0.0, 1.0, 0.0))),
	}

# Which cutouts should show a bulge for a given zone.
func getBulgeMeshesForZone(_zone:String) -> Array:
	# Body only, every zone. A throat bulge used to take the head cutout too, which put a lump
	# on the muzzle: the wrong place for a throat, and the muzzle is drawn from the side so a
	# swelling there reads as a deformed face. The neck and the whole torso are on the body
	# cutout, which is all a throat needs.
	var result:Array = getPatternMeshesForSlot(BodypartSlot.Body)

	var filtered:Array = []
	for themesh in result:
		if(themesh.visible && themesh.supportsBulges()):
			filtered.append(themesh)
	return filtered

# Where the swelling starts, in the zone's own bulge rest space. Usually the hole itself, but a
# throat reacts from the neck down rather than at the lips, so the mouth gets a bone instead.
# Returns null when it can't be worked out.
func getBulgeOriginRest(zone:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	if(BULGE_ORIGIN_BONE.has(zone)):
		var boneIdx:int = skeleton.find_bone(BULGE_ORIGIN_BONE[zone])
		if(boneIdx >= 0):
			# A bone's rest transform already lives in the space the cutouts' UVs are glued to,
			# so this needs no world round trip and no pose can shift it.
			return BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	return BulgeUtils.worldToRest(skeleton, BULGE_BONE.get(zone, "Hips"), anchor)

# Puts a bulge on this doll. entryWorld/tipWorld describe the inserted segment.
func applyBulge(zone:String, index:int, entryWorld:Vector3, tipWorld:Vector3, radius:float, strength:float, shade:float, halfLength:float = 0.0):
	var meshes:Array = getBulgeMeshesForZone(zone)
	if(meshes.empty()):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	var boneName:String = BULGE_BONE.get(zone, "Hips")
	var restEntry:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, entryWorld)
	var restTip:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, tipWorld)

	for themesh in meshes:
		themesh.setBulge(index, Vector2(restEntry.x, restEntry.y), Vector2(restTip.x, restTip.y), radius, strength, shade, halfLength)
		if(!dirtyMeshes.has(themesh)):
			dirtyMeshes.append(themesh)

# Hides everything on this doll's shaft that is deeper than the given world position, so it
# stops drawing over the body it's inside of.
func applyShaftClip(entryWorld:Vector3):
	var shaftInfo = getShaftInfo()
	if(shaftInfo == null):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	# Where the entry point sits along the shaft, in the space the shaft's UVs live in.
	var restEntryX:float = BulgeUtils.worldToRest(skeleton, "Penis", entryWorld).x
	for themesh in shaftInfo["meshes"]:
		# A rigged strapon has no skin shader to set params on, so it gets the clip through a
		# material_override instead. Same cut, same contract.
		if(themesh.has_method("setShaftClipAtRestX")):
			themesh.setShaftClipAtRestX(restEntryX)
		else:
			BulgeUtils.setPlainShaftClip(themesh, restEntryX)
		if(!dirtyMeshes.has(themesh)):
			dirtyMeshes.append(themesh)

# The bone driven belly swelling, which needs Doll3D's own pregnancy deform to cooperate with
# it. That only exists when Doll3D.gd is the modded one, so in a release build this quietly
# does nothing and the shader layer carries the effect on its own.
# ponytail: shader only on release builds, revisit if the bone layer ever becomes essential.
func applyBellyBulge(amount:float):
	if(doll.has_method("applyBellyBulge")):
		doll.applyBellyBulge(amount)

func clearBulgeState():
	for themesh in dirtyMeshes:
		if(!is_instance_valid(themesh)):
			continue
		if(themesh.has_method("clearBulges")):
			themesh.clearBulges()
			themesh.clearShaftClip()
		else:
			BulgeUtils.clearPlainShaftClip(themesh)
	dirtyMeshes.clear()
	if(doll.has_method("clearBellyBulge")):
		doll.clearBellyBulge()

# --- undoing the oral penis shrink ------------------------------------------------------------
# The base game shrinks an oversized cock to fit the mouth artwork: Doll3D.clampPenisScale, called
# from about twenty oral stage scenes on their suck states and nowhere else. It was a workaround
# for a shaft drawing straight through the head it was in, which the shaft clip now handles
# properly, and its visible side effect is the cock changing size partway through a scene: a
# state change shrinks it, the next character refresh puts it back.
#
# Doll3D.gd cannot be replaced from a mod in an exported build, and the twenty callers are stage
# scene scripts, so the clamp is undone here instead. Recomputed from the character rather than
# remembered, because a remembered maximum would also fight a legitimate shrink and would be wrong
# the moment a doll is reused for somebody else.
func restorePenisScale() -> void:
	if(scaleOverride > 0.0):
		# No character to ask: a test harness (or anything driving a doll directly) declares the
		# size it wants here, which is the job a character does in the game.
		if(wouldChangeScale(scaleOverride)):
			doll.setPenisScale(scaleOverride)
		return
	var character = getCharacter()
	if(character == null):
		return # previews, the anim picker and test harnesses have no character to ask
	# A worn strapon owns the scale while it is on. Delegating to the item is exactly what the
	# game does, and it is the only thing that knows which size that model wants.
	var worn = character.getWornStrapon() if character.has_method("getWornStrapon") else null
	if(worn != null):
		if(worn.has_method("updateDoll") && wouldChangeScale(1.0) && wouldChangeScale(1.1)):
			worn.updateDoll(doll)
		return
	var intended:float = 1.0
	if(character.hasBodypart(BodypartSlot.Penis)):
		var penis = character.getBodypart(BodypartSlot.Penis)
		if(penis != null && penis.has_method("getPenisScale")):
			intended = penis.getPenisScale()
	if(wouldChangeScale(intended)):
		doll.setPenisScale(intended)

# The strapon models only ever ask for 1.0 or 1.1, so if the doll is already at one of those the
# clamp hasn't touched it and the item doesn't need poking.
func wouldChangeScale(value:float) -> bool:
	return abs(doll.rememberedPenisScale - value) > 0.001

func getCharacter():
	if(doll == null || !is_instance_valid(doll) || !doll.has_method("getCharacterID")):
		return null
	var charID = doll.getCharacterID()
	if(charID is String):
		if(charID == ""):
			return null
		return GlobalRegistry.getCharacter(charID)
	return charID

# --- undoing the oral tip taper ---------------------------------------------------------------
# The oral insertion animations scale the shaft's own bones down so the tip disappears into the
# head. Measured on SexOralForced with a cock at scale 2: tease leaves the chain at 2/2/2, suck
# tapers it to 2/1.96/1.553 and suckinside to 2/1.388/0.382, which also shortens the last segment
# from 1.158 to 0.803. Crotch scenes and handjobs never taper. It is the same workaround the scale
# clamp was, baked into the animation data instead of a script: hide a shaft that would otherwise
# draw through the head. The shaft clip does that properly now, so the taper is only a cock that
# visibly changes shape.
#
# It lives in the animation, so it cannot be edited out: it is cancelled per frame instead. The
# animation writes the bones' `pose`, while `custom_pose` is the channel the game itself uses for
# bone scaling (Doll3D.setBoneScale) and nothing uses it on these two, so putting the inverse
# scale there leaves the pose's rotation and translation alone. Uniform scales commute, so the
# composition order does not matter here.
const TAPER_BONES:Array = ["Penis2", "Penis3"]

func unTaperShaftBones() -> void:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			continue
		var poseScale:Vector3 = skeleton.get_bone_pose(boneIdx).basis.get_scale()
		var worst:float = min(min(poseScale.x, poseScale.y), poseScale.z)
		if(worst <= 0.001):
			continue # degenerate, leave it alone rather than dividing by nothing
		var inverse:Vector3 = Vector3(1.0 / poseScale.x, 1.0 / poseScale.y, 1.0 / poseScale.z)
		skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY.scaled(inverse))
	taperCancelled = true

# Hands the bones back to the animation, so turning the fix off restores the base game look
# without needing a scene reload.
func restoreShaftTaper() -> void:
	if(!taperCancelled):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx >= 0):
			skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY)
	taperCancelled = false
