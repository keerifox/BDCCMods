extends Reference

# Diagnostics for the packaged mod. There is no console in a release build, so the state the
# solver sees gets appended to user://bulgedebug.txt a couple of times per second (capped),
# which can be read back afterwards. Set ENABLED = false to silence it.

const ENABLED:bool = false # flip to true to get user://bulgedebug.txt back
const BulgeDoll = preload("res://Player/Player3D/Bulge/BulgeDoll.gd")
const BulgeUtils = preload("res://Player/Player3D/Bulge/BulgeUtils.gd")

const PATH:String = "user://bulgedebug.txt"
const MAX_BYTES:int = 300000
const INTERVAL_MS:int = 500
const LAST_META:String = "bulgeDebugLastMs"

static func snapshot(dolls:Array):
	if(!ENABLED || !dueForWrite()):
		return

	var lines:Array = ["--- t=" + str(OS.get_ticks_msec()) + " dolls=" + str(dolls.size())]
	var index:int = 0
	for doll in dolls:
		index += 1
		if(doll == null || !is_instance_valid(doll)):
			lines.append("  doll" + str(index) + ": invalid")
			continue

		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			lines.append("  doll" + str(index) + ": no helper")
			continue
		var shaft = helper.getShaftInfo()
		var shaftText:String = "none"
		if(shaft != null):
			shaftText = "len=" + fmt(shaft["length"]) + " radius=" + fmt(shaft["radius"]) + " meshes=" + str(shaft["meshes"].size())
		lines.append("  doll" + str(index) + " char=" + str(doll.getCharacterID()) + " visible=" + str(doll.is_visible_in_tree()) + " shaft: " + shaftText)

		for zone in ["vagina", "anus", "mouth"]:
			var meshes:Array = helper.getBulgeMeshesForZone(zone)
			var flags:Array = []
			for themesh in meshes:
				flags.append(themesh.name + "(bulge=" + str(themesh.hasBulges) + ")")
			lines.append("      zone " + zone + " anchor=" + str(helper.getOrificeInfo(zone) != null) + " meshes=" + str(meshes.size()) + " " + str(flags))

		# Why a mesh might be unusable: no skin shader material, or no rest->UV fit.
		for slot in ["body", "head", "penis"]:
			for themesh in helper.getPatternMeshesForSlot(slot):
				if(themesh.supportsBulges()):
					continue
				lines.append("      UNUSABLE " + slot + "/" + themesh.name + " vis=" + str(themesh.is_visible_in_tree()) + " material=" + str(themesh.fancyMaterial != null) + " fit=" + str(themesh.uvFit != null))

		# The strapon slot on its own line: its cutouts are plain MeshInstances, so none of the
		# checks above apply to them and a strapon that refuses to bulge needs its own readout.
		if(doll.parts.has("strapon") && doll.parts["strapon"] != null):
			var straponMeshes:Array = helper.getShaftMeshesForSlot("strapon")
			var found:Array = []
			for themesh in straponMeshes:
				found.append(themesh.name + "(vis=" + str(themesh.is_visible_in_tree()) + " fit=" + str(BulgeUtils.fitOf(themesh) != null) + ")")
			lines.append("      strapon slotVisible=" + str(helper.hasVisibleSlot("strapon")) + " penisVisible=" + str(helper.hasVisibleSlot("penis")) + " shaftMeshes=" + str(straponMeshes.size()) + " " + str(found))

		if(shaft != null):
			for themesh in shaft["meshes"]:
				# A strapon's cutout has no hasShaftClip of its own: it carries the clip as a
				# material_override, so ask the override instead.
				var clipped = themesh.get("hasShaftClip")
				if(clipped == null):
					clipped = BulgeUtils.isPlainClipMaterial(themesh.material_override)
				lines.append("      shaftmesh " + themesh.name + " clip=" + str(clipped))

	# Raw geometry of every shaft/hole pair, so a match that never registers can be told apart
	# from one that registers and then shows nothing.
	for topDoll in dolls:
		if(topDoll == null || !is_instance_valid(topDoll)):
			continue
		var topHelper = BulgeDoll.forDoll(topDoll)
		if(topHelper == null):
			continue
		var shaft = topHelper.getShaftInfo()
		if(shaft == null || shaft["length"] < 0.05):
			continue
		var shaftDir:Vector3 = (shaft["tip"] - shaft["base"]) / shaft["length"]
		for bottomDoll in dolls:
			if(bottomDoll == null || !is_instance_valid(bottomDoll)):
				continue
			for zone in ["vagina", "anus", "mouth"]:
				var bottomHelper = BulgeDoll.forDoll(bottomDoll)
				if(bottomHelper == null):
					continue
				var orifice = bottomHelper.getOrificeInfo(zone)
				if(orifice == null):
					continue
				var along:float = (orifice["pos"] - shaft["base"]).dot(shaftDir)
				var lateral:float = (orifice["pos"] - (shaft["base"] + shaftDir * along)).length()
				var inwardDot:float = shaftDir.dot(orifice["inward"])
				lines.append("      pair " + str(topDoll.getCharacterID()) + " -> " + str(bottomDoll.getCharacterID()) + " " + zone + " along=" + fmt(along) + " lateral=" + fmt(lateral) + " inward=" + fmt(inwardDot) + " depth=" + fmt(shaft["length"] - along))

	writeLines(lines)

static func note(text:String):
	if(!ENABLED):
		return
	writeLines(["!!! " + text])

static func fmt(value:float) -> String:
	return str(stepify(value, 0.001))

static func dueForWrite() -> bool:
	var now:int = OS.get_ticks_msec()
	var last:int = Engine.get_meta(LAST_META) if Engine.has_meta(LAST_META) else -99999
	if(now - last < INTERVAL_MS):
		return false
	Engine.set_meta(LAST_META, now)
	return true

static func writeLines(lines:Array):
	var theFile:File = File.new()
	var exists:bool = theFile.file_exists(PATH)
	if(exists && theFile.open(PATH, File.READ) == OK):
		var size:int = theFile.get_len()
		theFile.close()
		if(size > MAX_BYTES):
			return
	if(theFile.open(PATH, File.READ_WRITE if exists else File.WRITE) != OK):
		return
	theFile.seek_end()
	# The editor project and the exported game share one user:// folder, so every session says
	# which build wrote it, otherwise the two overwrite each other's evidence.
	if(!Engine.has_meta("bulgeDebugHeaderDone")):
		Engine.set_meta("bulgeDebugHeaderDone", true)
		theFile.store_line("=== session: editor=" + str(OS.has_feature("editor")) + " driver=" + str(OS.get_current_video_driver()) + " mods=" + str(GlobalRegistry.loadedMods) + " ===")
	for line in lines:
		theFile.store_line(line)
	theFile.close()
