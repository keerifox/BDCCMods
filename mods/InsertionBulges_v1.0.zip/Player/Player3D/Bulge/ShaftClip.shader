// Stand in for MaterialForPartWithSkin, for shaft cutouts that are plain MeshInstances with a
// SpatialMaterial rather than MeshInstanceWithPattern. Rigged strapons are exactly that: they
// come in through the clothing pipeline, so they never get the skin shader and therefore have
// no way of hiding the stretch of themselves that is inside somebody.
//
// It does what their SpatialMaterial did (unshaded, transparent, no culling) plus the clip, so
// it can be dropped in as material_override without changing how a strapon looks. Going
// through material_override rather than replacing the surface material leaves the item's own
// material alone, which is what the dye path writes to.
shader_type spatial;
render_mode async_visible,blend_mix,depth_draw_opaque,cull_disabled,specular_disabled,unshaded;

uniform vec4 albedo : hint_color;
uniform sampler2D texture_albedo : hint_albedo;

// Same contract as the skin shader: a threshold on UV.x, values >= 1.5 disable it, and
// shaft_clip_dir picks which side of the threshold gets hidden.
uniform float shaft_clip;
uniform float shaft_clip_dir;
uniform float shaft_clip_feather;

void fragment() {
	vec4 albedo_tex = texture(texture_albedo, UV);

	if(shaft_clip < 1.5) {
		float clipDistance = (UV.x - shaft_clip) * shaft_clip_dir;
		albedo_tex.a *= 1.0 - smoothstep(-shaft_clip_feather, shaft_clip_feather, clipDistance);
	}

	ALBEDO = albedo.rgb * albedo_tex.rgb;
	ALPHA = albedo.a * albedo_tex.a;
}
