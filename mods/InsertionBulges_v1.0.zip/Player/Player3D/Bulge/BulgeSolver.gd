extends Reference

# Works out, purely from geometry, which doll is penetrating which and how deep, then asks
# the dolls to show the matching bulge and to clip away the hidden part of the shaft.
#
# Doing it geometrically instead of asking the sex engine means it also covers hand written
# scenes, fuck machines and anything a mod adds: if a shaft crosses an orifice anchor, it
# bulges. Insertion depth comes out of the same math for free, so the lump follows the
# thrusting animation without anyone having to drive it.

const BulgeUtils = preload("res://Player/Player3D/Bulge/BulgeUtils.gd")
const BulgeDebug = preload("res://Player/Player3D/Bulge/BulgeDebug.gd")
const BulgeDoll = preload("res://Player/Player3D/Bulge/BulgeDoll.gd")

const ZONES:Array = ["vagina", "anus", "mouth"]
# How far off the shaft's axis an orifice can sit and still count as penetrated. The lateral
# distance shrinks as a shaft goes deeper, so a hard cutoff here means the bulge only starts
# once the shaft is already half in: the strength fades out over the last stretch instead.
const LATERAL_TOLERANCE:Dictionary = {
	"vagina": 0.55,
	"anus": 0.55,
	# Measured across every oral stage scene: the ones that work sit at 0.24-0.38, and SexOral
	# approaches at a slant at 0.71. Muzzles differ in length and a head can be tilted any which
	# way, so the mouth genuinely needs the room the old comment here claimed but never gave it.
	"mouth": 0.8,
}
# Where the fade starts, as a fraction of the tolerance.
const LATERAL_FADE_START:float = 0.6
# How much the shaft has to be pointing into the hole for it to count as inserted. A real
# insertion runs close to the canal's own direction (measured ~0.98 on anal from behind); the
# loose old value let a withdrawn shaft register as barely entering the other hole at 0.55,
# and that spurious match is what made the bulge jump between the two.
#
# Per zone, because that failure was purely a crotch problem: vagina and anus sit a few tenths
# apart, so a loose gate let a withdrawing shaft claim the wrong one. The mouth has no
# neighbouring hole to be confused with, and oral poses come in at angles a crotch never does
# (0.43 measured on SexOral, 0.61 on SlutwallSexOral, against 0.87 on the head-on ones), so
# holding it to the crotch's threshold only ever threw away real insertions.
const MIN_INWARD_DOT:Dictionary = {
	"vagina": 0.6,
	"anus": 0.6,
	"mouth": 0.4,
}
# How much better a different hole has to score before the shaft is considered to have moved
# to it. Lower score is a better fit, so the new pick has to beat this fraction of the old.
const ZONE_SWITCH_MARGIN:float = 0.7
# The hole we are already in gets judged by looser rules, otherwise a withdrawing shaft gets
# rejected by the strict test, the other hole wins by default and the bulge jumps across the
# gap between them. It has to stop being a candidate before anything else can take over.
const STICKY_LATERAL_MULT:float = 1.9
const STICKY_INWARD_MULT:float = 0.5
# Insertion below this (in rest units) doesn't show anything yet.
const MIN_DEPTH:float = 0.15
# How far the hole may sit behind the shaft root and still count as fully inserted, in rest
# units. Poses press the bodies together past the root, and the balls hide that stretch.
const BASE_OVERSHOOT_SLACK:float = 1.0
# How far the tip has to be in before the body starts reacting, in rest units. Skin does not
# bulge the instant a tip touches the entrance, so a small delay here reads as real. Raise it
# for a later, subtler start, drop it towards zero to have the lump follow the tip immediately.
const ENTRY_DEADZONE:float = 0.5
# The cut sits this far deeper than the orifice anchor, since the anchor is under the skin and
# not on it. Too small and the cock fades away before it has entered anything.
const CLIP_SKIN_OFFSET:float = 0.35
# Depth at which the bulge reaches full strength, in rest units.
# The mouth used to sit at 0.45, BELOW ENTRY_DEADZONE, which made the ramp collapse: the
# denominator fell back on its 0.01 safety floor, so depthAmount jumped 0 to 1 within a
# hundredth of a unit and the throat snapped to full strength the instant anything entered and
# then never grew. It drives amplitude, shading and travel alike, so the whole throat effect was
# a step function. Same value as the crotch now, and the code floors it above the deadzone so
# this can't silently degenerate again.
const FULL_DEPTH:Dictionary = {
	"vagina": 1.1,
	"anus": 1.1,
	"mouth": 1.1,
}
# Falloff height of the swelling on the contour, as a multiple of the shaft's radius, capped
# so an enormous shaft doesn't smear the swelling over the whole torso.
const BUMP_HEIGHT_MULT:float = 3.0
const BUMP_HEIGHT_MAX:float = 1.6
# How far the contour is pushed out, as a multiple of the shaft's radius.
const BUMP_PUSH_MULT:float = 1.5
# How deep into the body the push is allowed to reach, in rest units. The body cutout is only
# about 1.2 deep from the anus anchor to the belly, so anything wider than this starts moving
# the back contour as well, which reads as the whole body bending instead of swelling.
const BUMP_REACH_RATIO:float = 1.3
const BUMP_REACH_MIN:float = 0.25
const BUMP_REACH_MAX:float = 0.5
# Hard ceiling on the push, in rest units. This one is not about taste: the cutouts only carry
# about 0.15-0.24 UV of transparent margin outside their silhouette, which is roughly 0.4 rest
# units on the body. Push the alpha edge further than the quad reaches and it simply stops
# having fragments to draw, which shows up as the belly being sliced off flat instead of round.
const BUMP_PUSH_MAX:float = 0.34
# How much of a cutout's measured margin the push may use. Leaves a little room so the very
# edge of the artwork never becomes the silhouette.
const MARGIN_USE:float = 0.85
# Gain on how far along the torso the bump rides with the tip (1.0 = follows it exactly), and
# which way it goes: a crotch bulge rides up the belly, a throat one goes down the neck.
const BUMP_TRAVEL:float = 1.0
# Where the bulge stops following the tip one to one and starts easing towards the limit.
const SOFT_LIMIT_KNEE:float = 0.75
# How much of the stretch between hole and tip stays swollen behind the tip. 0 = only a lump
# at the tip, 1 = the body stays full all the way back to the hole.
const BUMP_COLUMN:float = 0.85
# How much of that column the throat keeps flat, and how wide its falloff is as a fraction of the
# travel. A belly wants the plateau: it reads as still being occupied behind the tip. A throat
# running from the neck down the chest does not, because a plateau pushes a long stretch by exactly
# the same amount, and a constant push is the original silhouette translated in one piece. Measured
# it at 0.285 held over 1.5 rest units, which is the slab the effect looked like. Nearly no plateau
# plus a falloff tied to the length gives one smooth hump whose push varies along the body, so the
# contour reads as the chest swelling instead of the chest moving.
const MOUTH_COLUMN:float = 0.2
const MOUTH_SPREAD_FROM_TRAVEL:float = 0.6
const BUMP_TRAVEL_DIR:Dictionary = {
	"vagina": 1.0,
	"anus": 1.0,
	"mouth": -1.0,
}
# Where the front surface sits in the anchor bone's rest space, measured on the body cutout:
# its geometry spans x -0.92 .. 1.0 and the doll faces -x, so the belly is around -0.4 and
# the back around 0.8. Putting the push plane at the belly is what keeps the rear contour
# still: everything behind the plane is outside the shader's ramp.
const BUMP_FRONT_PLANE:Dictionary = {
	"vagina": -0.35,
	"anus": -0.35,
	# Re-measured in the body's rest space now that a throat bulge is placed there instead of in
	# the head's: the body cutout's front edge runs -0.18..-0.25 at neck height and -0.49..-0.54
	# through the chest, so this sits just inside the silhouette over the stretch the lump uses.
	"mouth": -0.28,
}
# The doll's own forward direction in rest space: the cutouts face -x, so that is the front.
const BUMP_FRONT_DIR:Vector3 = Vector3(-1.0, 0.0, 0.0)
# How far the front plane leans, per zone, as dx/dy in rest space. The plane is what decides which
# fragments get the full push, so a vertical one cuts across a body whose own front edge is not
# vertical: the neck edge sits at x -0.25 and the chest at -0.49, so a vertical plane at -0.28 has
# the chest in front of it and the neck behind, gives them different pushes, and joins the two with
# a straight run along the plane itself. That straight run is what reads as a rectangle down the
# chest. Measured slope between those two heights is 0.155, so the mouth leans by that and the
# plane follows the chest instead of slicing through it. The crotch stays vertical: over the short
# stretch a belly bulge covers, its front edge effectively is.
const BUMP_FRONT_TILT:Dictionary = {
	"vagina": 0.0,
	"anus": 0.0,
	"mouth": 0.155,
}
# How far past the entry the lump may run, per zone, in rest units. Without this a long shaft
# aims its tip out the far side of the body and drags the bulge outside with it.
const MAX_INSIDE_LENGTH:Dictionary = {
	"vagina": 3.0,
	"anus": 3.0,
	# Same as the crotch. From the neck (rest y 6.62) that reaches y 3.62 at full stretch, and
	# the body cutout's artwork bottoms out at 3.73, so it spans throat, chest and belly the way
	# the crotch spans belly to chest. The old 0.5 was measured in the head's space and pinned the
	# lump to the muzzle.
	"mouth": 3.0,
}
# Fixed size factor for the throat, in place of the profile average the crotch uses. A throat
# swells less than a belly does, and holding it constant is what stops the lump changing size as
# it slides. Careful reading this number: it scales girth, and girth enters the amplitude twice
# (directly and through sizeResponse), so 0.45 here is about 0.2 of the push, not 0.45.
const MOUTH_SHAPE_FACTOR:float = 0.45
# A human cock at normal size, measured off its own artwork. Everything else is expressed
# relative to it, so "twice as thick as a human" means the same thing everywhere.
const GIRTH_REFERENCE:float = 0.112
# How hard the shader lump answers to girth. Girth already scales the push once, so this makes
# the response quadratic: tuned so a human at size 1 is half strength and at size 2 is double
# that again, which is where this looked right.
const SIZE_RESPONSE:float = 0.5
const SIZE_RESPONSE_MAX:float = 3.0
# Bone deform layer. The DeformBelly bone is driven like a pregnancy, where 1.0 is already a
# full pregnant belly, so an insertion stays well under it. Deliberately a fixed amount and not
# scaled by the cock: the bone owns the whole belly, so making it answer to size turns every
# big cock into a pregnancy. Size is the shader lump's job, and now that the body cutout has
# room to grow the shader carries almost all of it: the bone only adds a hint of fullness.
const BONE_AMOUNT:float = 0.1
const BONE_MAX:float = 0.1
const MAX_BULGES_PER_DOLL:int = 2
# Used when we can't resolve the characters behind the dolls (previews, the anim picker, mods
# driving a doll directly), so those still get a sane looking bulge.
const DEFAULT_OVERSIZE:float = 0.9

static func solve(dolls:Array):
	var wantsBulges:bool = option("bulgesEnabled", true) && option("advancedShadersEnabled", true)
	var sizeModifier:float = option("bulgeSizeModifier", 1.0)
	# The bone layer has its own scale: the two look nothing alike, so turning the shader lump
	# down must not drag the belly deform with it, and either one alone is a valid setup.
	var boneModifier:float = option("bulgeBoneModifier", 1.0) if option("bulgeBonesEnabled", true) else 0.0
	# The two mouth gates are the ones that need retuning by eye per pose, so they can be
	# driven live from the dev harness. Release builds have no such options and fall back to the
	# constants above.
	var mouthLateral:float = option("bulgeMouthLateral", LATERAL_TOLERANCE["mouth"])
	var mouthInward:float = option("bulgeMouthInward", MIN_INWARD_DOT["mouth"])
	# Same for the two that decide the throat lump's shape: where the front surface sits and how
	# far down the neck it may run.
	var mouthFrontPlane:float = option("bulgeMouthFrontPlane", BUMP_FRONT_PLANE["mouth"])
	var mouthReach:float = option("bulgeMouthReach", MAX_INSIDE_LENGTH["mouth"])
	var mouthShape:float = option("bulgeMouthShape", MOUTH_SHAPE_FACTOR)
	var mouthTilt:float = option("bulgeMouthTilt", BUMP_FRONT_TILT["mouth"])
	var mouthColumn:float = option("bulgeMouthColumn", MOUTH_COLUMN)

	var activeDolls:Array = []
	var helpers:Dictionary = {} # doll instance id -> its BulgeDoll helper
	for doll in dolls:
		if(doll == null || !is_instance_valid(doll) || !doll.is_visible_in_tree()):
			continue
		# Everything the solver needs from a doll lives on a helper node, because a mod cannot
		# replace Doll3D.gd in an exported game. See BulgeDoll.
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		helper.clearBulgeState()
		# Undo the oral scenes' cock shrink. Outside the wantsBulges gate below on purpose: the
		# shrink is a visual artefact either way, and leaving a cock stuck at a clamped size just
		# because bulges are off would be worse than the artefact it was working around.
		if(option("bulgeKeepPenisScale", true)):
			helper.restorePenisScale()
		# Same reasoning for the animation's tip taper.
		if(option("bulgeKeepShaftShape", true)):
			helper.unTaperShaftBones()
		else:
			helper.restoreShaftTaper()
		helpers[doll.get_instance_id()] = helper
		activeDolls.append(doll)

	if(!wantsBulges || activeDolls.empty() || (sizeModifier <= 0.0 && boneModifier <= 0.0)):
		return

	var usedSlots:Dictionary = {} # doll -> how many bulges it already shows

	for topDoll in activeDolls:
		var topHelper = helpers[topDoll.get_instance_id()]
		var shaftInfo = topHelper.getShaftInfo()
		if(shaftInfo == null || shaftInfo["length"] < 0.05):
			continue

		var shaftBase:Vector3 = shaftInfo["base"]
		var shaftTip:Vector3 = shaftInfo["tip"]
		var shaftLength:float = shaftInfo["length"]
		var shaftDir:Vector3 = (shaftTip - shaftBase) / shaftLength
		var clipEntry = null
		var clipDepth:float = 0.0

		for bottomDoll in activeDolls:
			# One shaft can only be in one hole, so out of the holes it lines up with we take
			# the best match: centered on the axis and pointing straight in.
			var bestZone:String = ""
			var bestScore:float = 99999.0
			var bestAlong:float = 0.0
			var zoneScores:Dictionary = {}
			var zoneAlong:Dictionary = {}
			var zoneLateral:Dictionary = {}
			var memoryKey:int = bottomDoll.get_instance_id()
			var bottomHelper = helpers[bottomDoll.get_instance_id()]
			var lastZone:String = topHelper.zoneMemory.get(memoryKey, "")

			for zone in ZONES:
				# A doll can't fuck its own crotch, but it can suck itself off.
				if(bottomDoll == topDoll && zone != "mouth"):
					continue

				var orifice = bottomHelper.getOrificeInfo(zone)
				if(orifice == null):
					continue
				# The shaft has to be pointing into the hole, not just crossing near it. This
				# is what stops a receiver's own dangling cock from counting as a penetrator.
				var sticky:bool = (zone == lastZone)
				var inwardDot:float = shaftDir.dot(orifice["inward"])
				var inwardLimit:float = mouthInward if zone == "mouth" else MIN_INWARD_DOT.get(zone, 0.6)
				if(inwardDot < inwardLimit * (STICKY_INWARD_MULT if sticky else 1.0)):
					continue

				# Where the hole falls along the shaft, and how far it sits off its axis.
				var anchor:Vector3 = orifice["pos"]
				var alongShaft:float = (anchor - shaftBase).dot(shaftDir)
				# Balls deep, the hole ends up behind the shaft's own root and this used to
				# reject the match: the bulge switched off and the shaft went back to drawing
				# over the body, exactly at full penetration. Being seated past the root is
				# still being inserted, so allow some slack and treat it as fully in.
				if(alongShaft < 0.0 && alongShaft > -BASE_OVERSHOOT_SLACK):
					alongShaft = 0.0
				if(alongShaft < 0.0 || alongShaft > shaftLength):
					continue
				var lateral:float = (anchor - (shaftBase + shaftDir * alongShaft)).length()
				var lateralLimit:float = mouthLateral if zone == "mouth" else LATERAL_TOLERANCE.get(zone, 0.42)
				if(lateral > lateralLimit * (STICKY_LATERAL_MULT if sticky else 1.0)):
					continue
				if(shaftLength - alongShaft < MIN_DEPTH):
					continue

				# A long shaft passes close to both holes of a crotch. The one it is actually in
				# is the first one along its length: it cannot reach the second without going
				# through the first. Lateral distance only breaks near ties. Judging by fit
				# alone made a withdrawing shaft hand the bulge over to the other hole, which
				# moved it by the gap between them in a single frame.
				var score:float = alongShaft + lateral / max(inwardDot, 0.01)
				zoneScores[zone] = score
				zoneAlong[zone] = alongShaft
				zoneLateral[zone] = lateral
				if(score < bestScore):
					bestScore = score
					bestZone = zone
					bestAlong = alongShaft

			# Stick with the hole we were already in unless the other one is a clearly better
			# fit. Flipping mid thrust moves the bulge by the distance between the two holes,
			# which reads as the effect jumping instead of sliding.
			if(bestZone == ""):
				var _erased = topHelper.zoneMemory.erase(memoryKey)
				continue
			if(lastZone != "" && lastZone != bestZone && zoneScores.has(lastZone)):
				if(bestScore > zoneScores[lastZone] * ZONE_SWITCH_MARGIN):
					bestZone = lastZone
					bestAlong = zoneAlong[lastZone]
			topHelper.zoneMemory[memoryKey] = bestZone

			var skeleton:Skeleton = bottomHelper.getSkeletonNode()
			# The swelling is placed in the body's rest space, not the hole's bone: see BULGE_BONE.
			var boneName:String = BulgeDoll.BULGE_BONE.get(bestZone, "Hips")
			var orificeInfo = bottomHelper.getOrificeInfo(bestZone)
			if(skeleton == null || orificeInfo == null):
				continue
			var tipRest:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, shaftTip)

			var slotIndex:int = usedSlots.get(bottomDoll, 0)
			if(slotIndex >= MAX_BULGES_PER_DOLL):
				continue
			usedSlots[bottomDoll] = slotIndex + 1

			var depth:float = shaftLength - bestAlong
			var entryWorld:Vector3 = shaftBase + shaftDir * bestAlong
			# Floored above the deadzone: below it the ramp degenerates into a step (see FULL_DEPTH).
			var fullDepth:float = max(FULL_DEPTH.get(bestZone, 1.1), ENTRY_DEADZONE + 0.2)
			var depthAmount:float = clamp((depth - ENTRY_DEADZONE) / max(fullDepth - ENTRY_DEADZONE, 0.01), 0.0, 1.0)
			# Ease it so the growth has no kink where it tops out.
			depthAmount = depthAmount * depthAmount * (3.0 - 2.0 * depthAmount)
			var oversize:float = getOversizeFactor(topDoll, bottomDoll, bestZone)

			# Fade with lateral distance too, so the bulge is already at zero by the time the
			# match is dropped. Every threshold in here has to be crossed at zero strength or
			# it shows up as the effect popping in and out.
			# Same effective limit the gate used, or the fade would not reach zero exactly where the
			# match is dropped and the mouth would pop.
			var tolerance:float = mouthLateral if bestZone == "mouth" else LATERAL_TOLERANCE.get(bestZone, 0.55)
			var lateralFade:float = clamp((tolerance - zoneLateral.get(bestZone, 0.0)) / max(tolerance * (1.0 - LATERAL_FADE_START), 0.001), 0.0, 1.0)
			lateralFade = lateralFade * lateralFade * (3.0 - 2.0 * lateralFade)
			# The shaft's own artwork drives the size: how thick the inserted stretch measures
			# decides how much the body reacts, so a knot or an equine flare shows up as it
			# goes in instead of every cock bulging the same way.
			#
			# Not on the throat. Averaging over the inserted stretch means the average is taken
			# over more of the shaft the deeper it goes, so the lump's own size drifts with
			# depth (measured ~10% on a human). On a belly that reads as the shape of the thing
			# inside; on a throat it reads as the swelling changing size while it slides, so the
			# mouth takes a fixed factor on the shaft's mean girth and only its push and position
			# move. See MOUTH_SHAPE_FACTOR for why that factor is not 1.
			var shapeFactor:float = mouthShape
			if(bestZone != "mouth"):
				var entryT:float = clamp(bestAlong / max(shaftLength, 0.001), 0.0, 1.0)
				shapeFactor = clamp(BulgeUtils.averageProfileBetween(shaftInfo.get("profile", []), entryT, 1.0), 0.75, 1.35)

			var girth:float = shaftInfo["radius"] * shapeFactor
			# Girth counts twice: once for the size of the lump, once for how strongly the body
			# answers to it. A thin cock stays subtle, a thick one dominates.
			var sizeResponse:float = clamp(SIZE_RESPONSE * girth / GIRTH_REFERENCE, 0.0, SIZE_RESPONSE_MAX)
			if(option("bulgeSizeOverride", false)):
				sizeResponse = option("bulgeSizeOverrideValue", SIZE_RESPONSE)
			topHelper.lastSizeResponse = sizeResponse
			var spread:float = min(girth * BUMP_HEIGHT_MULT * clamp(oversize, 0.6, 1.4), BUMP_HEIGHT_MAX)
			var amplitude:float = girth * BUMP_PUSH_MULT * sizeResponse * depthAmount * oversize * sizeModifier * lateralFade
			# How much of the body's depth the push may touch. Absolute units, because it is a
			# property of the body: a huge shaft gets a stronger push, not a deeper one, or the
			# far side of the body starts moving too. The push stays under the reach so the
			# warp cannot fold.
			amplitude = min(amplitude, getPushCeiling(bottomDoll, bestZone))
			var reach:float = clamp(amplitude * BUMP_REACH_RATIO, BUMP_REACH_MIN, BUMP_REACH_MAX)
			amplitude = min(amplitude, reach * 0.9)
			var shade:float = clamp(depthAmount * oversize * 0.9 * lateralFade, 0.0, 1.0)

			# Where on the contour the swelling sits: straight in front of the orifice, riding
			# up the torso with insertion depth. Nothing here uses the shaft's direction, which
			# is the point: the animation drives the depth, the body owns the shape.
			var maxInside:float = mouthReach if bestZone == "mouth" else MAX_INSIDE_LENGTH.get(bestZone, 1.0)
			# Where the body starts reacting. Usually the hole itself; for a throat it is the
			# neck, since a cock in a mouth shows on the neck and down, never at the lips.
			var anchorRest = bottomHelper.getBulgeOriginRest(bestZone)
			if(anchorRest == null):
				continue
			var direction:float = BUMP_TRAVEL_DIR.get(bestZone, 1.0)
			var travel:float = 0.0
			if(bestZone == "mouth"):
				# Same formula as the crotch below, only the length is measured differently. A
				# throat cannot borrow the tip's own height: the head turns, so mapping the tip
				# into the body's rest space says nothing about how far down the neck it is, and
				# in a kneeling pose it lands at neck height whether the shaft is barely in or
				# balls deep. How much shaft is inside is the same quantity measured a way no
				# rotation can spoil, so the lump runs deeper as the thrust goes deeper exactly
				# like a belly does. Not depthAmount: that saturates at FULL_DEPTH, which would
				# cap the travel long before a long shaft has finished going in.
				var mouthRise:float = max(depth - ENTRY_DEADZONE, 0.0)
				travel = softLimit(mouthRise, maxInside) * BUMP_TRAVEL * direction
			else:
				# Put the swelling where the tip actually is, not at a scaled guess: taking the
				# tip's own height in the receiver's rest space keeps the lump on the cock at
				# every depth instead of only lining up at full insertion. Only the height is
				# borrowed, so the shape still belongs to the body and not to the shaft's angle.
				# Same deadzone on the position, so the lump does not start creeping up the
				# belly before the tip is properly in.
				var rise:float = max((tipRest.y - anchorRest.y) * direction - ENTRY_DEADZONE, 0.0)
				# One to one with how far the tip has gone in, so the swollen stretch is as long
				# as the part of the shaft that is inside: a long equine fills the belly further
				# up than a short human does. Only the last stretch before the body runs out is
				# eased off, and softly, because a hard clamp freezes the bulge mid thrust.
				travel = softLimit(rise, maxInside) * BUMP_TRAVEL * direction
			# The whole stretch between the hole and the tip stays full, not just the tip: the
			# swelling is a column whose far end tracks the tip, so the body reads as still
			# occupied behind it and empties from the top down as the shaft pulls out.
			# The column runs back from the tip towards the hole: 0 = only the tip swells,
			# 1 = everything from the hole to the tip stays full.
			var tipY:float = anchorRest.y + travel
			var column:float = mouthColumn if bestZone == "mouth" else BUMP_COLUMN
			var columnHalf:float = abs(travel) * column * 0.5
			if(bestZone == "mouth"):
				# With almost no plateau the falloff is the whole shape, so it has to span the
				# throat to chest stretch rather than just the shaft's girth, or the swelling
				# collapses into a small lump at the tip.
				spread = min(max(spread, abs(travel) * MOUTH_SPREAD_FROM_TRAVEL), BUMP_HEIGHT_MAX)
			var centreRest:Vector3 = Vector3(mouthFrontPlane if bestZone == "mouth" else BUMP_FRONT_PLANE.get(bestZone, -0.35), tipY - travel * column * 0.5, anchorRest.z)
			var centreWorld:Vector3 = BulgeUtils.restToWorld(skeleton, boneName, centreRest)
			# Leaning the direction leans the plane with it, and turns the band's own axis to run
			# along the contour rather than straight down the body.
			var tilt:float = mouthTilt if bestZone == "mouth" else BUMP_FRONT_TILT.get(bestZone, 0.0)
			var frontDir:Vector3 = (BUMP_FRONT_DIR + Vector3(0.0, tilt, 0.0)).normalized()
			var frontWorld:Vector3 = BulgeUtils.restDirToWorld(skeleton, boneName, frontDir)

			if(amplitude > 0.005):
				bottomHelper.applyBulge(bestZone, slotIndex, centreWorld, centreWorld + frontWorld * reach, spread, amplitude, shade, columnHalf)

			# Optional bone layer: real geometry on top of the shader, so it can go past what
			# the cutout's margin allows. Blunt by nature, the bone owns the whole belly, so it
			# swells the area rather than putting a lump at an exact height. Crotch only, since
			# there is no bone for a throat.
			if(boneModifier > 0.0 && bestZone != "mouth"):
				# Same amount whatever is in there. It still fades in with depth so it doesn't
				# pop on the moment a match registers.
				var boneAmount:float = option("bulgeBoneOverrideValue", BONE_AMOUNT) if option("bulgeBoneOverride", false) else BONE_AMOUNT
				topHelper.lastBoneAmount = boneAmount
				bottomHelper.applyBellyBulge(clamp(boneAmount * boneModifier * depthAmount, 0.0, BONE_MAX))


			# Hiding the shaft is only allowed once it is genuinely inside. The anchor sits
			# under the skin, so clipping right at it eats shaft that is still in plain view,
			# and a pose that merely rests against a hole would fade the cock for no reason.
			# The cut slides with how much is actually in, instead of switching on at a depth
			# threshold: at no insertion it sits at the tip and hides nothing, at full insertion
			# it sits at the entry. That kills two artefacts at once, the shaft's tip popping
			# back into view when the gate flips, and the tip being hidden on a shallow or off
			# axis thrust where the bulge itself has already faded to nothing.
			var insertion:float = depthAmount * lateralFade
			if(depth > clipDepth):
				clipDepth = depth
				clipEntry = entryWorld + shaftDir * (CLIP_SKIN_OFFSET + (1.0 - insertion) * depth)

		if(clipEntry != null):
			topHelper.applyShaftClip(clipEntry)

	BulgeDebug.snapshot(activeDolls)

# How hard the hole is being stretched, using the game's own measure: free room is the
# comfortable insertion size minus what's going in, in cm, so it goes negative when the
# shaft is too big. A hole that takes it easily barely bulges, a stuffed one bulges a lot.
static func getOversizeFactor(topDoll, bottomDoll, zone:String) -> float:
	var topID = topDoll.getCharacterID()
	var bottomID = bottomDoll.getCharacterID()
	if(!(topID is String) || !(bottomID is String) || topID == "" || bottomID == ""):
		return DEFAULT_OVERSIZE

	var bottomChar = GlobalRegistry.getCharacter(bottomID)
	var topChar = GlobalRegistry.getCharacter(topID)
	if(bottomChar == null || topChar == null):
		return DEFAULT_OVERSIZE

	var slot = BodypartSlot.Head if zone == "mouth" else zone
	if(!bottomChar.hasBodypart(slot)):
		return DEFAULT_OVERSIZE

	var freeRoom:float = bottomChar.getPenetrationFreeRoom(slot, topChar.getPenisSize())
	return clamp(0.35 + max(-freeRoom, 0.0) / 18.0, 0.3, 1.7)


# The most the receiver's cutouts can be pushed before running out of artwork, in rest units.
# Measured from the meshes themselves, with the constant only as a fallback.
static func getPushCeiling(bottomDoll, zone:String) -> float:
	var helper = BulgeDoll.forDoll(bottomDoll)
	if(helper == null):
		return BUMP_PUSH_MAX
	var meshes:Array = helper.getBulgeMeshesForZone(zone)
	var room:float = -1.0
	for themesh in meshes:
		if(!themesh.is_visible_in_tree()):
			continue
		var margin:float = BulgeUtils.getFrontMargin(themesh)
		if(margin <= 0.0):
			continue
		room = margin if room < 0.0 else min(room, margin)
	if(room <= 0.0):
		return BUMP_PUSH_MAX
	return room * MARGIN_USE

# Linear up to the knee, then eases towards the limit instead of stopping dead. A plain min()
# here froze the bulge in place for the deep half of every thrust, which read as a jump.
static func softLimit(value:float, limit:float) -> float:
	var knee:float = limit * SOFT_LIMIT_KNEE
	if(value <= knee):
		return value
	var rest:float = max(limit - knee, 0.001)
	return knee + rest * tanh((value - knee) / rest)

# Options are read by name with a fallback, so this works as a mod without having to ship a
# copy of GlobalOptions.gd: on a game that doesn't know these settings the defaults apply,
# and on one that does the player's choices win.
static func option(optionName:String, fallback):
	if(OPTIONS == null || !(optionName in OPTIONS)):
		return fallback
	return OPTIONS.get(optionName)
